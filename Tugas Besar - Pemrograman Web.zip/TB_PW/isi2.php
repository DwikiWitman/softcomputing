<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<h3>Tradisi Omed-Omedan</h3>
									<img src="img/omed.jpg" alt="omed.jpg">
									<p>Tradisi omed-omedan merupakan warisan nenek moyang sejak dulu dan  dilakukan secara turun temurun. Dahulu, omed-omedan hanya dilakukan hanya dengan tarik-tarikan, perkembangan jaman yang pesat lalu berubah ada ciuman. Pada saat sedang berciuman, air diguyur agar peserta tidak kepanasan dan ciumannya tidak menjadi lebih lama. Tradisi omed-omedan ini, dilakukan oleh dua kelompok yakni muda dan mudi. Pemuda berdiri membentuk barisan ke belakang dan saling berpelukan pada pinggang orang yang di depan. Demikian pula dengan kelompok pemudi. Jumlahnya tidak dibatasi. Pada saat dikasih aba-aba maka kelompok dua kelompok ini saling tarik menarik ke belakang, bertumpuh pada kaki dengan lengan di pingggang. Orang yang mengambil posisi di depan harus mampu berjalan ke depan sementara yang lain menarik berlawanan ke belakang. Saat orang yang di depan berhasil maju ke depan bertemu, disaat itulah keduanya berpelukan dan berciuman.</p>
							<br/>
								</div>
							<h5 class="push_4 grid_6">Dikutip dari: <a href="http://balidulo.blogspot.co.id/2013/10/kebudayaan-bali-zaman-dulu.html" target="_blank">balidulo.blogspot.co.id</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>