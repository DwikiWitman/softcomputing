<?php
session_start();
include "koneksi.php";

$query = mysql_query("select * from user where username = '".$_POST["username"]."' AND password = '".$_POST["password"]."' ");

$hasil = mysql_fetch_array($query);

if ($hasil[0]!="")
{
	$_SESSION["name"]=$hasil[1];
	header('Location: admin-page.php');
}
else
{
	$_SESSION["error"]="Username atau password Anda salah!";
	header('Location: login-admin.php');
}

?>