<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<h3>Pantai Geger</h3>
							<img src="img/geger.jpg" alt="geger.jpg">
							<p>Jika Anda mengutamakan agenda berenang saat liburan, inilah pantai pertama yang harus ada dalam daftar. Hanya lima menit perjalanan dari Nusa Dua Golf Course, Pantai Geger akan menyambut Anda dengan gradasi warna air biru kehijauan. Ombaknya tak besar sehingga nyaman untuk aktivitas renang. Pantai ini juga berada di sebelah St Regis Nusa Dua Resort.</p>
							<p>Pasir pantainya berwarna cokelat muda, halus dan padat, memungkinkan Anda bermain voli pantai atau arena balap lari bagi anak - anak. Beberapa restoran terletak tak jauh dari sini, yang terkenal sebagai tempat 'sunday brunch' bagi para turis. Jika beruntung, Anda bisa menemui para penghasil rumput laut bekerja di sebuah area antara Kafe Geger dan Kuil Geger.</p>
							<p>Belum cukup? Baiklah, satu keuntungan lain. Geger adalah salah satu pantai di mana kerap kali para turis berjemur secara 'topless'.</p>
						
							<h5 class="push_4 grid_6">Dikutip dari: <a href="http://www.belantaraindonesia.org/2012/06/6-pantai-tersembunyi-di-bali.html" target="_blank">http://www.belantaraindonesia.org</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>