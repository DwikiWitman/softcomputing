<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<h3>Upacara Ngaben</h3>
									<img src="img/ngaben.jpg" alt="ngaben.jpg">
									<p>Pulau Bali yang juga dikenal sebagai “Pulau Seribu Pura” memiliki ritual khusus dalam memperlakukan leluhur atau sanak saudara yang telah meninggal. Apabila di tempat lain orang yang meninggal umumnya dikubur, tidak demikian dengan masyarakat Hindu di Bali. Sebagaimana penganut Hindu di India, mereka akan menyelenggarakan upacara kremasi yang disebut Ngaben, yaitu ritual pembakaran mayat sebagai simbol penyucian roh orang yang meninggal. Tradisi budaya ngaben ini merupakan warisan leluhur masyarakat Bali dan diteruskan secara turun temurun ke anak cucunya. Upacara pengabenan ini juga menjadi salah satu penarik wisatawan di Bali karena keunikan dan keseniannya.
									</p>
									<br/>
								</div>
							<h5 class="push_4 grid_6">Dikutip dari: <a href="http://balidulo.blogspot.co.id/2013/10/kebudayaan-bali-zaman-dulu.html" target="_blank">balidulo.blogspot.co.id</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>