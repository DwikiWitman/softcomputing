<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="generator"
    content="HTML Tidy for HTML5 (experimental) for Windows https://github.com/w3c/tidy-html5/tree/c63cc39" />
    <meta charset="utf-8" />
    <title>Bali Cak Culture</title>
    <link rel="stylesheet" href="css/reset.css" />
    <link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="all" />
    <script src="js/jquery-1.3.2.min.js"></script>
    <script src="js/login.js"></script>
    <script src="js/logout.js"></script>
    <link rel="stylesheet" href="css/960_header.css" />
    <link rel="stylesheet" href="css/layout.css" type="text/css" media="all" />
  </head>
  <body>
    <!---HEADER TEMPAT LAMBANG==-->
    <div class="container_12">
      <div class="header">
        <div class="grid_3">
          <!---lambang bali cak==-->
          <a href="index.php">
            <img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo" />
          </a>
        </div>
      </div>
    </div>
    <div class="clear"></div>
    <div class="container_12">
      <div class="menu">
        <ul>
          <li>
            <a href="index.php">Home</a>
          </li>
          <li>
            <a href="about.php">About</a>
          </li>
          <li>
            <a href="gallery.php">Gallery</a>
          </li>
        </ul>
      </div>
    </div>
    <div class="clear"></div>
    <!--container untuk header content-->
    <div class="container_12_header_fixed">
      <!--Ruang kosong utk fixed header-->
      <div class="masthead"></div>
      <!--Ruang navigasi konten-->
      <!--Ruang isi konten-->
      <div class="mainContent grid_12">
        <!--ARTIKEL 1><-->
        <div id="content1">
          <article>
            <div>
              <h3>Ogoh-ogoh</h3>
              <img src="img/ogoh-ogoh.jpg" alt="ogoh-ogoh.jpg" />
              <p>Ogoh-ogoh merupakan karya seni patung dalam kebudayaan Bali. Budaya Ogoh-ogoh ini tetap bertahan hingga saat ini.
              Ogoh-ogoh ini kebudayaan yang menggambarkan kepribadian “Bhuta Kala” dan sudah menjadi ikon ritual yang secara
              tradisi sangat penting dalam penyambutan Hari Raya Nyepi atau Tahun Baru Saka. Seluruh umat Hindu Dharma akan
              bersukaria menyambut kehadiran tahun baru itu dengan mengarak-arakan “ogoh-ogoh” yang dibarengi dengan perenungan
              tentang yang telah terjadi dan sudah dilakukan selama ini pada saat “Pangerupukan” atau sehari setelah menjelang
              Hari Raya Nyepi, peristiwa dan prosesinya setiap tahunnya sama yaitu pada setiap banjar membuat ogoh-ogoh. Mengingat
              pentingnya Budaya ogoh-ogoh ini, sampai sekarang masih tetap bertahan dan lestari. Disamping itu dengan keberadaan
              arak-arakan “Ogoh-ogoh” yang sudah menjadi tradisi inilah yang menambah daya tarik wisata. Balipun memiliki
              budaya yang menjadi salah satu andalan kepariwisataan.</p>
            </div>
            <h5 class="push_4 grid_6">Dikutip dari: 
            <a href="http://balidulo.blogspot.co.id/2013/10/kebudayaan-bali-zaman-dulu.html"
            target="_blank">balidulo.blogspot.co.id</a></h5>
          </article>
        </div>
        <div class="clear"></div>
      </div>
    </div>
  </body>
</html>
