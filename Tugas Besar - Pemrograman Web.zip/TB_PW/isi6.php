<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<h3>Permainan Tradisional</h3>
									<img src="img/permainan.jpg" alt="permainan.jpg">
									<p>Permainan Tradisional Bali sekarang jarang bisa kita temukan apalagi di daerah perkotaan, perkembangan tekhnologi yang pesat hampir menenggelamkan mereka. Ada puluhan bahkan ratusa permainan tradisional yang ada, orang tua juga seolah-olah tidak memperhatikan dan cenderung tidak mampu mengarahkan anak-anak mereka dalam melakukan permainan yang memang ternyata cukup susah, karena permainan tradisional lebih menonjolkan permainan berkelompok yang membutuhkan kekompakan dan kebersamaan dan secara tidak langsung mendidik anak itu lebih bisa mengenal lingkungannya yang majemuk, bergaul dengan tidak memandang status sosial dan kebersamaanya, kesetiakawanan dengan suasana ceria di lingkungan mereka. Banyak permainan tradisional yang ada di Bali seperti; meong-meongan, megoak-goakana, metajog, nyen durine nyongkok, engkeb–engkeban, main gangsing, main tajog. Dengan perkembangan iptek yang pesat, anak-anak cenderung menggunakan tekhnologi yang ada seperti video games yang bisa dimainkan dari handphone, play station dan melalui internet. Mereka sepertinya lebih asik bermain alat tersebut, tidak lagi berinteraksi dengan lingkungan dengan teman sesamanya. Mereka hanya terfokus untuk menang mengumpat kalau kalah. Anak-anak sampai kecanduan dan tidak fokus belajar, apalagi permainan yang menggunakan handphone yang katanya ada ‘radiasi‘ yang bisa mempengaruhi sel-sel tubuh dan perkembangan otak, ini tentunya akan sangat berbahaya bagi perkembangan anak. Peran aktif orang tua sangat dibutuhkan dalam mengarahkan dan membimbing mereka.</p>
									<br/>
								</div>
							<h5 class="push_4 grid_6">Dikutip dari: <a href="http://balidulo.blogspot.co.id/2013/10/kebudayaan-bali-zaman-dulu.html" target="_blank">balidulo.blogspot.co.id</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>