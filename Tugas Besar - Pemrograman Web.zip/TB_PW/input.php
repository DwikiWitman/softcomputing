<?php
include "koneksi.php";

$retval = mysql_query("insert into user values('".$_POST['id']."','".$_POST['username']."','".$_POST['password']."','".$_POST['keterangan']."')");

if(! $retval )
{
  die('Could not enter data: ' . mysql_error());
}
header('Location: admin-page.php');
?>