<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						<h3>Kesenian Sakral Tidak Sama dengan Kesenian Pertunjukan</h3>	
						<p>Bali terkenal dengan spiritualitas dan keseniannya. Di masa lampau setiap aktivitas yang dilakukan oleh orang Bali adalah wujud dari ‘Bhakti’ atau ‘Yadnya’ atau ‘Ngayah’ (pengabdian tulus) kepada Sang Pencipta.</p>
						<p>Terlebih-lebih kesenian. Semua bentuk kesenian yang dijalankan orang Bali adalah ‘bhakti’. Menari adalah bhakti. Membuat patung dan ukiran adalah bhakti. Megegitaan (menyanyikan lagu suci) adalah bhakti. Mekekawin (membaca lontar berbahasa ‘Kawi’) adalah bhakti. Megambel (memainkan gambelan) adalah bhakti.</p>
						<img src="img/tari-sakral.jpg" alt="tari-sakral.jpg">
						<p>Dari sekian banyak jenis kesenian itu, beberapa diantaranya ada yang bersifat sakral sehingga hanya boleh dilakukan di hari dan kesempatan tertentu saja (biasanya odalan atau ritual khusus) dan ada juga yang boleh dilakukan di hari-hari biasa meskipun sedang tidak ada ritual tertentu.</p>
						<p>Semenjak Bali menjadi daerah tujuan wisata, banyak aktivitas berkesenian yang tadinya didedikasikan untuk ‘Ngayah/berbakti/Mengabdi’ pelan-pelan dipertontonkan/ dipertunjukan di depan wisatawan dengan maksud menghibur dan dibayar (dikomersialisasikan).</p>
						<p>Melihat begitu massifnya kesenian Bali yang dikomersialisasikan, banyak yang mengkhawatirkan kesakralan kesenian Bali menjadi tidak terjaga.</p>
						<p>Namun rupanya kekhawatiran itu telah diantisipasi dengan baik, yakni dengan cara membedakan antara kesenian yang digelar untuk maksud ‘yadnya’ dengan yang digelar untuk maksud pertunjukan (komersial).</p>
						<p>Pembedaan dilakukan dengan cara menghilangkan bagian-bagian tertentu dari kesenian tersebut ketika digelar untuk maksud pertunjukan. Tari Barong (Barong Dance) misalnya, ketika digelar untuk maksud pertunjukan/atraksi wisata, maka ada bagian-bagian dari ritual tari barong itu yang dihilangkan. Sementara ketika digelar untuk maksud upacara maka harus sesuai dengan aslinya.</p>
						<h5 class="push_4 grid_6 omega">Dikutip dari: <a href="http://popbali.com/10-fakta-tentang-bali-yang-jarang-terungkap/11/" target="_blank">popbali.com</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>