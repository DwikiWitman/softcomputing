
<!DOCTYPE html> 
<html>
<head>
		<title>Bali Cak Culture</title>
		<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
		<script src="js/jquery-1.3.2.min.js"></script>
		<script src="js/login.js"></script>
		<script src="js/logout.js"></script>
</head>
	
<body>
		<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		
		<!---MENU NAVIGASI TEMPAT HOME, GALLERY DAN ABOUT---->
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					<li>
							<?php
								session_start();
								if (!isset($_SESSION["name"]))
								{	/*Untuk menampilkan kata login*/
									echo '<a href="#" class="login-click">Login</a>';			
								}
								else
								{   /*Untuk menampilkan Selamat datang dan nama user yg sedang login*/
									echo '<a href="#" class="logout-click" style="padding: 15px 40px;">Welcome Back,'.$_SESSION["name"].'!'. '</a>';
								}
							?>
					</li>
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
		
		<!--LOGIN CARD CLICK-->
		<div class="container_12">
			<div class="push_9">
				<!--PHP yg ada alert js untuk memberi alert bahwa user/pass salah -->
				<?php
					if (isset($_SESSION["error"]) && isset($_SESSION["error"])!="" )
					{
						echo	'<script type="text/javascript">' .
									'alert("' .$_SESSION["error"]. '");' . 	
								'</script>';
						/* PHP bisa menampilkan alert gagal login, pakai echo abis tu pake js...*/
								
						session_unset(); 	/* unset semua session,  kalo unset dgn  $_SESSION["error"]=""	 masih bug dia -__-  */
					}	
				?>
				<!-- Form login yg bisa dihide dishow -->
				<div class="login-card login-stuff">	
					<!--Form Login User-->
					<form method="POST" action="check-login-user.php"> 
						<input type="text" name="username" placeholder="Username">
						<input type="password" name="password" placeholder="Password">				
						<input type="submit" name="login" value="Login">
					</form>
					
					<!--Form Login Admin-->
					<a href="login-admin.php">Login to Admin Page >></a>					
				</div>				
			</div>
		</div>
		
		<!--LOGOUT CARD CLICK-->
		<div class="container_12">
			<div class="push_9">
				<div class="logout-card logout-stuff">
					<form method="POST" action="login-admin.php"> 
						<input type="submit" name="<?php echo $_SESSION["name"]; ?>" value="View Admin Page">
					</form>
					<form method="POST" action="logout.php"> 
						<input type="submit" name="logout" value="Logout">
					</form>
				</div>
			</div>
		</div>
	
		<!--SLIDER TEMPAT ANIMASI SLIDE GAMBAR ---->
		<div class="container_12">
			<!-- Slider -->
			<div class="slider">
				<ul>
					<li>
						<img src="img/bali.jpg">	
					</li>
				</ul>					
			</div>
		</div>
		<div class="clear"></div>
		
		<!--TEMPAT KONTEN/ISI CULTURE BALI YANG TERLUPAKAN---->
		<div class="container_12 wrap">
					<!--TILES 1---->
					<div class="grid_3 tiles">
						<img src="images/ogoh-ogoh.jpg" width="200" height="200" alt="ogoh-ogoh">
						<div class="go-top">
							<h3>Ogoh-ogoh</h3>
							<div class="clear"></div>
							<p>Ogoh-ogoh merupakan karya seni patung kebudayaan Bali. Ogoh-ogoh ini kebudayaan yang menggambarkan kepribadian “Bhuta</p>
							<a href="isi1.php">Read More</a>
						</div>
						
					</div>
					
					<!--TILES 2---->
					<div class="grid_3 tiles">
						<img src="images/omed.jpg" width="200" height="200" alt="Omed-omedan">
						<div class="go-top">
							<h3>Omed-Omedan</h3>
							<div class="clear"></div>
							<p>
								Dahulu, omed-omedan hanya dilakukan hanya dengan tarik-tarikan, perkembangan jaman yang pesat lalu berubah ada ciuman.
							</p>
							<a href="isi2.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 3---->
					<div class="grid_3 tiles">
						<img src="img/ngaben.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Upacara Ngaben</h3>
							<div class="clear"></div>
							<p>
							Pulau Bali yang juga dikenal sebagai “Pulau Seribu Pura” memiliki ritual khusus dalam memperlakukan leluhur atau sanak saudara</p>
							
							<a href="isi4.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 4---->
					<div class="grid_3 tiles">
						<img src="images/siap-selem.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Tradisi Mesatua</h3>
							<div class="clear"></div>
							<p>
								Tradisi mesatua Bali yang dituturkan oleh para orang tua pada anaknya akan terlihat dari perilaku anak tersebut sehari-harinya, 
							</p>
							<a href="isi3.php">Read More</a>
						</div>
					</div>
		</div>
		
	<div class="clear"> </div>
	<!--TEMPAT KONTEN/ISI CULTURE BALI YANG Hilang---->
		<div class="container_12 wrap">
					<!--TILES 1---->
					<div class="grid_3 tiles">
						<img src="img/subak.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Sistem Subak Bali</h3>
							<div class="clear"></div>
							<p>Subak Bali diputuskan menjadi Warisan Dunia oleh UNESCO pada Jumat, 29 Juni 2012. Akademisi Pertani
							</p>
							<a href="isi5.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 2---->
					<div class="grid_3 tiles">
						<img src="img/permainan.jpg" width="200" height="200" alt="Omed-omedan">
						<div class="go-top">
							<h3>Permainan Tradisional</h3>
							<div class="clear"></div>
							<p>
								Permainan Tradisional Bali sekarang jarang bisa kita temukan apalagi di daerah perkotaan, perkembangan tekhnologi yang
							</p>
							<a href="isi6.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 3---->
					<div class="grid_3 tiles">
						<img src="img/bajak-sawah.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Alat Pembajak Sawah</h3>
							<div class="clear"></div>
							<p>
								Keunikan Budaya Bali dan Pesatnya Pariwisata Bali kita tidak bisa terlepas dari sebuah dunia yang disebut Pertanian Bali.
							</p>
							<a href="isi7.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 4---->
					<div class="grid_3 tiles">
						<img src="img/rujak-kuah-pindang.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Rujak Pindang khas Bali</h3>
							<div class="clear"></div>
							<p>
								Anda ingin menyantap makanan yang segar-segar dan pedas? Rasanya tepat untuk mencoba
							</p>
							<a href="isi8.php">Read More</a>
						</div>
					</div>
		</div>
		
	<div class="clear"> </div>
	
	<!--TEMPAT KONTEN/ISI Wisata---->
		<div class="container_12 wrap">
					<!--TILES 1---->
					<div class="grid_3 tiles">
						<img src="img/balangan.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Pantai Balangan</h3>
							<div class="clear"></div>
							<p>
							Saat Pantai Dreamland sudah dipenuhi resor dan tak lagi sepi, para peselancar melangkahkan kaki mereka ke Balangan.
							</p>
							<a href="isi9.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 2---->
					<div class="grid_3 tiles">
						<img src="img/ungasan.jpg" width="200" height="200" alt="Omed-omedan">
						<div class="go-top">
							<h3>Pantai Ungasan</h3>
							<div class="clear"></div>
							<p>
								Pantai yang terletak di wilayah paling selatan Pulau Bali ini didaulat sebagai salah satu pantai tercantik. 
							</p>
							<a href="isi10.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 3---->
					<div class="grid_3 tiles">
						<img src="img/amed.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Pantai Amed</h3>
							<div class="clear"></div>
							<p>
								Kalau Anda lebih berhasrat untuk melihat keindahan bawah laut Pulau Dewata, Pantai Amed adalah jawabannya.
							</p>
							<a href="isi11.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 4---->
					<div class="grid_3 tiles">
						<img src="img/geger.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Pantai Geger</h3>
							<div class="clear"></div>
							<p>
								Jika Anda mengutamakan agenda berenang saat liburan, inilah pantai pertama yang harus ada dalam daftar.
							</p>
							<a href="isi12.php">Read More</a>
						</div>
					</div>
		</div>
		
	<div class="clear"> </div>
	
	<!--TEMPAT KONTEN/ISI Wisata---->
		<div class="container_12 wrap">
					<!--TILES 1---->
					<div class="grid_3 tiles">
						<img src="img/sapi.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Mengapa Hindu Menghormati Sapi ?</h3>
							<div class="clear"></div>
							<p>
							Melihat banyaknya arca-arca sapi di tempat suci Hindu baik yang ditemukan di situs purbakala maupun di tempat-
							</p>
							<a href="isi13.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 2---->
					<div class="grid_3 tiles">
						<img src="img/tari-sakral.jpg" width="200" height="200" alt="Omed-omedan">
						<div class="go-top">
							<h3>Kesenian Sakral Bukan Kesenian Pertunjukan</h3>
							<div class="clear"></div>
							<p>
								Bali terkenal dengan spiritualitas dan keseniannya. Di masa lampau setiap aktivitas
							</p>
							<a href="isi14.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 3---->
					<div class="grid_3 tiles">
						<img src="img/balinese-caste-system.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Tingkatan-Tingkatan Kasta Orang Bali</h3><br/>
							<p>
								Jika anda pernah mengunjungi Bali, anda akan merasa di permainkan jika anda pikir nama setiap orang yang anda
								</p>
							<a href="isi15.php">Read More</a>
						</div>
					</div>
					
					<!--TILES 4---->
					<div class="grid_3 tiles">
						<img src="img/Barong.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							<h3>Pertunjukan Kesenian Tari Barong Ubud</h3>
							<div class="clear"></div>
							<p>
								Saat anda wisata di Bali, tentunya anda tidak hanya ingin diam di hotel atau menghabiskan waktu ke shoping mall,
							</p>
							<a href="isi16.php">Read More</a>
						</div>
					</div>
		</div>
		
	<div class="clear"> </div>
	
	
	<!--FOOTER TEMPAT ABOUT---->
	<div id="about" class="container_12 footer">
			<div class="grid_6">
				<h3>
					Created by:
					<br/>				
					<br/>Yohanes Dwiki Witman (140707748).
					<br/>Widodo  (140707763).
				</h3>
			</div>
				
			<div class="grid_6" style="text-align: justify;">
				<p>	
					<em>"Website dibuat 'tiles' sehingga terlihat simpel. Konten beberapa dibuat sendiri dan diambil dari website lain. Best viewed in Chrome, beberapa bagian mungkin belum terlihat sempurna di browser lainnya!"
					</em>
				</p>
			</div>
	</div>
	<div class="clear"> </div>
	
</body>
</html>