<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<h3>Mengapa Umat Hindu Menghormati Sapi?</h3>	
						<p>Melihat banyaknya arca-arca sapi di tempat suci Hindu baik yang ditemukan di situs purbakala maupun di tempat-tempat suci yang masih aktif digunakan sebagai tempat peribadatan mengundang sebuah anggapan salah kaprah terhadap Hindu. Orang sebagian besar orang, Hindu identik dengan penyembah sapi. Apa lagi pada kenyataannya sebagian besar umat Hindu di dunia berpantang untuk mengkonsumsi daging sapi. Benarkah Hindu memuja Sapi?</p>
						<p>Berdasarkan peradaban Veda, sapi memang merupakan binatang yang sangat di sakralkan. Diuraikan bahwa sapi merupakan lambang dari ibu pertiwi yang memberikan kesejahtrean kepada semua makhluk hidup di bumi ini. Karena itulah para umat manusia diajarkan untuk tidak menyemblih dan memakan daging sapi. Selain mempunyai manfaat di dalam kehidupan rohani, sapi juga memelihara kita di dalam kehidupan material kita seperti misalnya dengan memberikan susu sapi dan berbagai produk susu. Selain susu dan berbagai produk, sapi juga memberikan berbagai jenis bahan obat-obatan seperti misalnya kencing sapi dan tahi sapi yang bahkan ilmuwan modern sekalipun menerima bahwa air kencing sapi dan kotoran sapi mengandung zat anti septik yang bisa digunakan untuk mengobati berbagai jenis penyakit. Di India, didalam sistem pengobatan Ayur Veda, terdapat teknik yang di sebut pengobatan panca gavya. Panca gavya adalah lima jenis produk yang di hasilkan oleh sapi yaitu; susu, yogurt, ghee, kencing sapi dan kotoran sapi. Panca gavya ini diangap sebagai bahan bahan yang menyucikan. Bahkan di dalam yajna dan memandikan pratima di berbagai kuil, bahan bahan ini sangat diperlukan. Tanpa panca gavya, seseorang tidak bisa menginstalasi pratima di dalam kuil. Selain bahan bahanyang bisa di komsumsi dari segi material, sapi juga membantu para petani di dalam berbagai hal. Sapi jantan di gunakan untuk membajak dan kotoran sapi digunakan untuk pupuk.</p>
						<img src="img/sapi.jpg" alt="sapi.jpg">
						<p>Sri Krsna sendiri yang muncul ke dunia material ini memberikan contoh kepada kita semua untuk menghormati sapi. Beliau bahkan lebih memementingkan sapi dari semua makhluk hidup lainya termasuk para brahmana. Seprti diuraikan di dalam sastra “namo brahmaëya-deväya go-brähmaëa-hitäya ca jagad-dhitäya kåñëäya govindäya namo namaù”.</p>
						<p>Di vrndavan, tradisi menghormati sapi-sapi masih berlangsung sampai sekarang. Di beberpa tempat di daerah pedalaman di Vraja bumi, ketika mereka memasak roti (capati), roti pertama akan diberikan kepada sapi karena mereka mengangap bahwa krsna hanya akan menerima persembahan kalau mereka memuaskan sapi-sapi dan para brahmana. kemudian roti kedua di berikan kepadaorang suci yan kebetulan lewat di daerah desa tersebut dan roti lainnya, di persembahkan kepada Sri Krsna.</p>
						<p>Disini hendaknya kita membedakan istilah menghormati dan memuja. Orang Hindu memperlakukan sapi secara istimewa adalah untuk menghormati sapi, bukan memuja sapi. Hindu hanya memuja satu Tuhan, “eko narayanan na dwityo”sti kascit” tapi menghormati seluruh ciptaan Tuhan, terutama yang disebut ibu, para dewa yang mengatur alam material dan semua umat manusia.</p>
						<p>Dalam tradisi Hindu dikenal beberapa entitas yang dapat disebut sebagai ibu yang harus kita hormati, yaitu;
							<br/>1. Ibu yang melahirkan kita, yaitu ibu kandung kita sendiri.
							<br/>2. Ibu yang menyusui kita walaupun tidak mengandung kita.
							<br/>3. Ibu yang memelihara dan mengasuh kita walaupun tidak melahirkan dan menyusui kita.
							<br/>4. Sapi yang telah memberikan kita susu, sumber panca gavya dalam pengobatan Ayur Vedic dan juga yang tenaganya telah kita gunakan untuk membantu pekerjaan-pekerjaan kita.
							<br/>5. Ibu pertiwi, yaitu bumi dan alam ini yang telah memberikan penghidupan pada kita dan harus kita jaga kelestariannya.
						</p>
						<p>Sekarang kita gunakan hati nurani kita, apakah kita akan tega membunuh dan memakan daging sapi yang sudah kita minum susunya, yang sudah membantu pekerjaan-pekerjaan fisik kita dalam menarik pedati dan juga membajak sawah?Disaat manusia dapat dengan mudahnya membunuh, memotong kepala ayam dan sapi tanpa perasaan, maka disaat itulah mereka akan memotong kepala manusia dan bahkan ibu kandungnya sendiri seperti memotong kepala seekor ayam.</p>
						<p>Saya masih teringat di masyarakat kita di kalangan hindu di Bali. Ketika saya masih kecil, orang tua saya sering memperingatkan bahwa kalau kamu makan daging sapi, kamu tidak boleh datang ke pura tanpa mandi terlebih dahulu. Peringatan ini di berikan olehorang tua saya dan sudah merupakan peringatan turun temurun dari nenek moyang kami. Namu sayangnya beberapa orang berangapan bahwa karena kalau kita makan daging sapi, maka kita tidak bisa masuk ke pura, itu berarti sapi adalah binatang haram. Ternyata setelah kita amati dan mempelajari kitab suci veda, ternyata sapi merupakan binatang yang suci yang dihormati oleh para dewa sekalipun. Bukanlah karena sapi merupakan binatang haram, maka kalau kita makan daging sapi kita tidak bisa ke pura tetapi karena sapi merupakan binatang yang sangat suci, sehinga kalau kita memakan daging sapi, maka kita diangap orang yang sangat berdosa, degan demikian tidak bisa masuk ke pura. Karena itu, setelah makan daging sapi, kita harus menyucikan diri, paling tidak mandi terlebih dahulu sebelum memasuki tempat suci.</p>
						<p>Ini bukan berarti bahwa kita bisa berlangsung memakan daging sapi dan kemudian mandi dan menyucikan diri. Tidak! Itu bukanlah proses prayascita yang sejati. Proses prayascita yang sejati adalah menyucikan diri dari perbuatan berdosa, merenungkan kegiatan berdosa tersebut dan berusaha untuk menghindari kegiatan tersebut.</p>
						<p>Kadang kadang, orang sadar akan kegiatan berdosa namun melakukan kegitan berdosa lagi. Dengan demikian saya mengangap proces melakukan kegiatan berdosayang berulang ulang dan penyucian berulang ulang sebagai hal yang tidak berguna. Ini sama halnya dengan gajah mandi ( kunjara-sauca-vat), karena gajah membersihkan dirinya dengan mandi namun begitu selesai mandi dan kembali ke daratan, sang gajah akan menghamburkan lumpur pada kepala dan badannya. ( Srimad Bhagavatam, 6.1.10).</p>
						<p>Jadi ajaran dari orang tua kita, tidak boleh ke pura setelah makan daging sapi, hendaknya diambil serius dan menghindari daging sapi selama lamanya dan berusaha mengerti keagungan sapi. Diuraikan juga bahwa orang yang membunuh sapi, atau makan daging sapi, akan menderita di planet neraka selama ratusan tahun untuk membayar satu dari bulu sapi yang mereka makan. kalau seseorang makan daging sapi yang memliki seratus ribu bulu, maka orang tersebut mesti menderita di neraka selama 100.000 dikali 100 tahun. Sudah tentunya kita menghindari penyemblihan sapi dan makan daging sapi bukan karena takut untuk masuk neraka tapi karena rasa kasih sayang kita kepada sapi yang telah berkenan memberikan kita berbagai jenis makanan seperti yang telah diuraikan di atas. </p>
						<h5 class="push_4 grid_6 omega">Dikutip dari: <a href="http://dwijasuastana.blogspot.co.id/2010/10/mengapa-umat-hindu-menghormati-sapi.html" target="_blank">dwijasuastana.blogspot.co.id</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>