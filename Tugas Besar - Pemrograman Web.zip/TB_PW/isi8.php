<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<h3>Rujak Kuah Pindang khas Bali</h3>	
						<p>Anda ingin menyantap makanan yang segar-segar dan pedas? Rasanya tepat untuk mencoba Rujak Kuah Pindang. Apa itu Rujak Kuah Pindang? Mungkin sebagian dari Anda banyak yang bertanya tentang apa itu makanan yang satu ini, karena memang yang selama ini dikenal seperti rujak buah, rujak sayur, ataupun rujak cingur. Ketiganya lebih familiar ketimbang Rujak Kuah Pindang. Hal itu wajar saja karena memang Rujak Kuah Pindang terbilang rujak yang eksklusif karena hanya ada di Pulau Dewata Bali.</p>
						<p>Rujak Kuah Pindang ini merupakan makanan khas Bali yang hanya ada di pulau indah ini. Salah satu penjual Rujak Kuah Pindang bisa Anda sambangi di Jalan Bukit Tunggal, Denpasar. Sebenarnya nama aslinya ialah Rujak Gelogor, namun entah mengapa kemudian banyak orang yang menyebutnya Rujak Kuah Pindang. Rujak ini biasanya banyak disukai oleh wisatawan yang berasal dari luar Bali karena didaerah/ negaranya memang tak akan ditemukan.</p>
						<img src="img/rujak-kuah-pindang.jpg" alt="rujak-kuah-pindang.jpg">
						<p>Rujak Kuah Pindang berisikan banyak buah-buahan yang dirajang seperti mangga muda, nanas, jambu air, bengkuang, dan mentimun. Kemudian buah-buahan hasil rajang tersebut disiram oleh kuah yang banyak. Tahukah Anda bahwa kuah tersebut berasal dari ikan pindang yang dicampurkan dengan gerusan cabai dan terasi. Dan itulah yang membedakan antara Rujak Kuah Pindang dengan jenis rujak yang lainnya. Mungkin Anda yang baru pertama kali merasakan rujak yang satu ini akan keheranan, kok bisa-bisanya rujak diberi kuah pindang.</p>
						<p>	Lokasi <br>
							Rujah Kuah Pindang berlokasi di Jalan Bukit Tunggal No 27, Pemecutan, Kota Denpasar, Bali –Indonesia.<br/>
							Jam buka: jam 10.00 – 19.00<br/>
							Menu andalan: Rujak Kuah Pindang, Es Buah<br/>
							Harga: Rp 6.000<br/>
						</p>
						
					
							<h5 class="push_4 grid_6">Dikutip dari: <a href="http://bali.panduanwisata.id/restaurants/sudah-pernahkah-mencicipi-rujak-kuah-pindang-denpasar" target="_blank">bali.panduanwisata.id" target="_blank">balidulo.blogspot.co.id</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>