<?php
include "koneksi.php";

/* buat html di php dgn echo, pertama deklarasikan css n grid yg dipakai */
echo '
<html>

<head>
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/table.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
</head>

<body>
';

/* Untuk update database */
echo '
	<div class="container_12">
		<form method="POST" class="elegant-aero" action="eksekusiupdate.php">
			<label><span>Id :</span></label>
			<input type="text"  name="id" value="'.$_POST['id'].'" readonly><br/>
			
			<label><span>Username :</span></label>
			<input type="text" name="username"  value="'.$_POST['username'].'"><br/>
			
			<label><span>Password :</span></label>
			<input type="password" name="password"  value="'.$_POST['password'].'"><br/>
			
			<label><span>Keterangan :</span></label>
			<input type="text" name="keterangan"  value="'.$_POST['keterangan'].'"><br/>
						
			<input type="submit" class="button" value="Simpan Data">
			<a href="admin-page.php" class="button"> Kembali</a>
		</form>
	</div>
';

echo '
</body>
</html>
';
?>