<?php
session_start();
include "koneksi.php";

$query = mysql_query("select * from user where username = '".$_POST["username"]."' AND password = '".$_POST["password"]."' ");

$hasil = mysql_fetch_array($query);

if ($hasil[0]!="")
{
$_SESSION["nama"]=$hasil[1];
header('Location: a.html');
}
else
{
$_SESSION["eror"]="Username atau password anda salah!";
header('Location: index.html');
}

?>