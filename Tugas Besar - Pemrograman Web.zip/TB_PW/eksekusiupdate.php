<?php
include "koneksi.php";

$retval = mysql_query("update user set username = '".$_POST['username']."', password='".$_POST['password']."', keterangan='".$_POST['keterangan']."' where iduser='".$_POST['id']."'");

if(! $retval )
{
  die('Could not update data: ' . mysql_error());
}
header('Location: admin-page.php');
?>