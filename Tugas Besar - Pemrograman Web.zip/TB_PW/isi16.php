<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="index.php">About</a>
					</li>
					<li>
						<a href="index.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						<p><strong>Pertunjukan Kesenian Tari Barong Ubud</strong>
							<br/>Saat anda wisata di Bali, tentunya anda tidak hanya ingin diam di hotel atau menghabiskan waktu ke shoping mall, tanpa melihat sesuatu yang unik dan hanya ada di Bali, seperti pertujukan kesenian khas tradisional budaya Bali. Salah satu pertunjukan seni yang paling di cari di Ubud adalah pertunjukan tari Barong Ubud dan tari kecak Ubud.
							<br/><br/>Tarian Barong sebuah kesenian tari tradisional di Bali, yang sebagian penarinya menggunakan topeng dan kostum yang menyerupai hewan. Jenis tari Barong yang paling banyak di minati adalah tari Barong Ket. Lalu apa itu Barong Ket?
							<br/><br/>Jika di lihat dari bentuknya, Barong Ket merupakan perpaduan bentuk binatang antara harimau, singa, ular naga dan sapi. Seluruh badan dari Barong Ket, dihiasi dengan ukiran tradisional Bali yang berbahan dasar kulit sapi dan dalam ukiran tersebut terdapat puluhan cermin kaca yang berukuran kecil.
							<br/><br/>Jadi pada saat ada cahaya yang mengenai cermin kaca, membuat wujud dari Barong kelihatan berkilauan. Untuk membuat tampak seperti bintang, maka di Barong Ket anda akan melihat banyak Bulu. Bulu ini terbuat dari serat daun tanaman yang dikeringkan dan biasanya mengunakan daun pandan dan ijuk.
							<br/><br/>Untuk menarikan Barong Ket diperlukan dua orang penari, kedua penari ini memiliki nama Juru Bapang atau sering juga disebut dengan nama Juru Saluk. Penari di bagian kepala Barong di namai Juru Bapang satu dan penari yang di bagian ekor dinamai Juru Bapang dua. Tentunya pada saat pementasan tarian Barong Ket, juga disertai pementasan tarian Rangda.
							<br/><br/>Rangda adalah sebuah sosok yang kelihatan sangat seram, karena di gunakan untuk mewakili simbul keburukan. Sedangakan Barong Ket adalah sibul kebajikan. Oleh karena itu, setiap pementasan tarian Barong Ket, pastinya akan ada pementasan Rangda. Hal ini meyimbulkan perbedaan abadi antara kebajikan dan keburukan.
							<br/><br/>Untuk mengiringi tari Barong di Ubud digunakan musik traditional Bali yang disebut dengan nama Gambelan. Jenis Gambelan yang digunakan adalah Gamelan Semar Pegulingan. Bagi yang pertama kali mendengar musik Gambelan Semar pegulingan, pastinya akan terdengar aneh di telinga, tapi setelah anda melihat penari yang bergerak mengikuti irama musik Gambelan, anda pastinya akan terbiasa.
						</p>
						<h5 class="push_4 grid_6 omega">Dikutip dari: <a href="http://www.rentalmobilbali.net/tari-barong-ubud/" target="_blank">www.rentalmobilbali.net</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>