<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						<h3>Tingkatan Kasta Orang Bali</h3>	
						<p>Jika anda pernah mengunjungi Bali, anda akan merasa di permainkan jika anda pikir nama setiap orang yang anda temui bernama Wayan. Anak-anak orang Bali diberi nama berdasarkan sesuai dengan kasta keluarga yang di miliki dan di urutkan berdasarkan kelahiran mereka. 90% dari populasi masing-masing memiliki satu kasta, nama-nama seperti Made. Wayan dan Nyoman begitu sangat populer.</p>
						<p>Masyarakat Bali didasarkan pada sistem kasta Hindu, meskipun tidak serumit bentuk yang terjadi di India. Versi sederhana ini menjelaskan penempatan orang ke dalam 4 kasta yang berbeda: Brahmana (pendeta), Ksatria (penguasa / ksatria ), Wesia (pedagang ), Sudra (petani).</p>
						<img src="img/balinese-caste-system.jpg" alt="balinese-caste-system.jpg">
						
						
						
						<p><strong>Nama</strong>
							<br/>Setiap kasta memiliki nama yang unik, dan kadang juga membingungkan dimana anak laki-laki dan perempuan menggunakan nama yang sama. Untuk membedakannya antara pria dan wanita dengan nama yang sama, anak laki-laki akan menggunakan kata "i" sebelum nama mereka dan anak perempuan mereka menggunakan kata "Ni" sebelum nama mereka.
						</p>
						
						<h3>Brahmana (Pendeta)</h3>
						<p>Ini merupakan kasta para pemuka agama dan orang suci yang melakukan upacara keagamaan yang sangat penting.
							<br/>Ida Bagus - untuk anak laki-laki.
							<br/>Ida Ayu or Dayu - untuk anak perempuan.
						</p>
						
						<h3>Ksatria (Penguasa/Kesatria)</h3>
						<p>Anggota kasta ini mencangkup beberapa bangsawan dan raja (contohnya. Anggota keluarga kerajaan) 
							<br/>Anak Agung, Agung, Dewa - untuk anak laki-laki
							<br/>Anak Agung, Agung, Dewi, Dewayu - untuk anak perempuan
							<br/>Cokorda, Dewa Agung untuk anggota kerajaan yang berkuasa.
						</p>
						<p>Kasta Ksatria juga memiliki nama tengah sebagai berikut :
							<br/>Raka - saudara perempuan/lakui-laki tertua 
							<br/>Oka - bungsu
							<br/>Rai - saudara perempuan/laki-laki termuda
							<br/>Anom - perempuan muda
							<br/>Ngurah - seseorang yang berwenang
						</p>
						
						<h3>Wesia (Pedagang)</h3>
						<p>Gusti (tuan) - untuk laki-laki dan perempuan
							<br>Dewa - untuk laki-laki
							<br>Desak - untuk perempuan
						</p>
						
						<h3>Sudra (Petani)</h3>
						<p>Merupakan populasi paling banyak (lebih dari 90%) di Bali memiliki kasta ini
							<br/>Wayan, Putu, Gede -  anak pertama laki-laki 
							<br/>Wayan, Putu, Iluh -  anak pertama perempuan 
							<br/>Made, Kadek, Nengah - anak kedua untuk laki-laki dan perempuan
							<br/>Nyoman, Komang - anak ketiga untuk laki-laki dan perempuan 
							<br/>Ketut - anak keempat untuk laki-laki dan perempuan 
						</p>
						<p>Jika seseorang merupakan anak ke lima maka beralih kembali ke nama yang sama dengan anak pertama lahir.Sistem yang unik ini hanyalah sedikit bagian dari hal yang menarik di Bali. Jadi jangan heran jika anda memanggil "Made" di tengah orang banyak dan beberapa orang akan berbalik memanggil anda!</p>
						
						<h5 class="push_4 grid_6 omega">Dikutip dari: <a href="http://blog.kura2guide.com/balinese-caste-system/?lang=in" target="_blank">blog.kura2guide.com</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>