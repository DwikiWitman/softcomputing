<?php
session_start();

if (isset($_SESSION["name"]))
{
	header('Location: admin-page.php');
}
?>

<!DOCTYPE html> 
<html>
<head>
		<title>Login Bali Cak Culture</title>
		<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
		<script src="js/jquery-1.3.2.min.js"></script>
		<script src="js/login.js"></script>
</head>
	
<body>
		<!--LOGIN CARD CLICK-->
		<div class="container_12">
			<div class="push_4 login-admin-card">	
				<h1>Login Admin</h1><br/>
				<form method="POST" action="check-login-admin.php"> 
					<input type="text" name="username" placeholder="Username">
					<input type="password" name="password" placeholder="Password">				
					<input type="submit" name="login" value="Login">
				</form>
				<a href="index.php"><< Back to main menu</a>
				<!--PHP yg ada alert js untuk memberi alert bahwa user/pass salah -->
				<?php
					if (isset($_SESSION["error"]))
					{
						echo	'<script type="text/javascript">'.'alert("' .$_SESSION["error"]. '");' . '</script>';
						/* PHP bisa menampilkan alert gagal login, pakai echo abis tu pake js...*/
						
						session_unset(); 	/* unset semua session,  kalo unset dgn  $_SESSION["error"]=""	 masih bug dia -__-  */
					}	
				?>
				
			</div>
		</div>		
</body>
</html>