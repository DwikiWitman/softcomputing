<?php
include "koneksi.php";

$retval = mysql_query("DELETE from user WHERE iduser = '".$_POST['id']."'");

if(! $retval )
{
  die('Could not enter data: ' . mysql_error());
}


header('Location: admin-page.php');
?>