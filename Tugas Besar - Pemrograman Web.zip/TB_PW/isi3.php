<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<article>
						<h3>Tradisi Mesatua Bali, Kearifan Lokal Nan Kian Punah</h3>	
						<p>Penulis masih ingat ketika masa-masa kecil dulu, kira-kira awal tahun 80-an, orang tua penulis, terutama Bapak, begitu gemar mesatua siap selem dan Ketimun Emas. Teringat betapa ketika itu penulis bersama saudara-saudara yang lain begitu tertegun tatkala mendengar cerita tentang Siap selem yang penuh dengan nilai-nilai kasih sayang keluarga dan pengenalan tentang sifat baik dan buruk. Bagaimana sekarang?</p>
						<img src="img/siap-selem.jpg" alt="siap-selem.jpg">
						<p>Indonesia yang sarat dengan adat dan istiadatnya, juga memiliki berbagai jenis cerita rakyat yang penuh dengan pesan-pesan kearifan. Sebut saja di Bali, ada ratusan macam cerita rakyat seperti: Cerita Siap(ayam) Selem(hitam), ketimun Mas, I Bawang & I Kesuna, Cupak & Gerantang, dan lain-lainnya. Di daerah lain, seperti Padang, Sumatera Barat, ada cerita Malin Kundang. Biasanya, cerita-cerita itu, dituturkan oleh para orang tua kepada anak-anaknya menjelang tidur ataupun pada saat santai sore dirumah.</p> 
						<p>Penulis sendiri mengalami hal ini. Dimana orang tua penulis dulu sering bercerita tentang Siap Selem menjelang tidur. Sekilas ceritanya begini:"Ada cerita, seekor ayam betina bernama I Siap Selem( Si Ayam Hitam Betina), dia mempunyai anak cukup banyak, I Siap selem ini adalah tipikal ibu yang sangat protektif terhadap anak-anaknya dan juga sangat cerdik. Anaknya yang paling bungsu bernama I Ulagan(Si tanpa Bulu). Keluarga Ayam ini mempunyai musuh abadi bernama Men Kuwuk(Rubah;Lubak). pada suatu hari, keluarga ayam ini berkelana mencari makan sampai sore hari, tanpa dinyana, mereka tersesat dan pada saat itu hujan dengan lebat. Rombongan keluarga ayam yang berjumlah 7 orang termasuk si bungsu Ulagan, tersesat dalam sebuah hutan, mereka tiba didepan sebuah rumah yang ternyata adalah rumah Men Kuwuk(Si Lubak), Rubah adalah binatang yang gemar memangsa ayam. Mendapat tamu yang adalah mangsanya, tentu saja Men Kuwuk dan family girang bukan kepalang, Mereka mempersilahkan keluarga ayam untuk menginap di rumah mereka. Tapi, ternyata Si Siap Selem, sudah waspada dengan kebaikan Men Kuwuk. Karena dia tahu sepak terjang Si Lubak terhadap kaum ayam. Dan masing-masing nich..sudah pada atur strategi, Si Lubak dengan strategi santap malam daging ayamnya sedangkan Si Ayam Hitam dengan strategi melindungi anak-anaknya dari dingin dan derasnya air hujan tapi juga memasang jebakan untuk Lubak & family. Singkat cerita, hujan sudah reda, belakang rumah tempat keluarga ayam berlindung, keluarga ayam sudah menyiapkan rencana. Mereka akan kabur dari rumah Si Lubak dan memasang jebakan batu. Di bagian lain, Si Lubak dan anak-anaknya sudah siap-siap mengintai dan menerkam mangsa lezat di rumah mereka.</p> 
						<p>Malam yang mencekam, Si ayam hitam sudah mengintruksikan anak-anaknya untuk satu persatu kabur dari rumah Si Lubak. pertama yang paling sulung, karena mempunyai sayap disuruh terbang melompati pagar rumah Si Lubak. Terdengarlah suara, Blurrrr...kedubrakkk...Si Lubak berteriak dari balik kamar, hey Siap Selem apa itu? Dijawab Siap selem, Oh itu ada buah kelapa jatuh, Si Lubak manggut-manggut aja(dalam pikirannya dia ingin memastikan keluarga ayam tertidur semuanya. Demikian seterusnya, satu persatu,anggota keluarga ayam terbang melarikan diri pada malam itu. Sedangkan jebakan berupa batu-batu hitam, juga telah disiapkan menyerupai onggokan ayam tertidur. Ternyata, Si kecil bungsu/Si Ulagan yang tidak punya sayap, tidak bisa ikut menyelamatkan diri. Sang Ibu, dengan berat hati memberi pesan pada si Ulagan untuk menggunakan kecerdikannya untuk menipu para Lubak yang kelaparan. Semua anggota keluarga ayam hitam sudah berhasil menyelamatkan diri, tinggal si Ulagan saja dengan gagah berani menunggui jebakan yang mereka buat. Dan, di sisi lain, seluruh anggota keluarga Lubak sudah semakin mendekat, siap menerkam di suasana gelap gulita itu, tapi sebelum itu Si Lubak mengetes dulu apabila seluruh keluarga ayam sudah tertidur, Si ayam hitam dipanggil-panggil, ayam hitam, ayam hitam! Tidak ada jawaban,ayam hitam, ayam hitam! Lagi tidak ada jawaban. Akhirnya disimpulkan seluruh keluarga ayam sudah tertidur, Semua anggota Lubak pun menyerbu dan melompat ke tempat keluarga ayam. Dannn......ternyata mereka semua menerkam batu-batu hitam yang dikira ayam tersebut. Apa yang terjadi? Karena para Lubak menerkam batu, jadinya, gigi mereka pada tanggal semua, giginya copot! Si Ulagan yang melihat kejadian itu, tidak bisa menahan tawa, karena para lubak garang yang ada didepannya pada tidak punya gigi sama sekali. Lubak-lubak itu meringis kesakitan. Si Ulagan pun bernyanyi,Ngik..Ngik Ngak Gigi Pungak Ngugut Batu( Ngik Ngik ngak, Giginya nerkam batu)".</p>
						<p>Demikian seklumit kisah Siap Selem yang sering penulis dengar dulu. Apa kira-kira pesan dari cerita itu? Secara umum, anak-anak dipesankan untuk senantiasa bersikap baik dengan mendengar nasehat orang tua dan tidak boleh serakah. Karakter yang baik ditunjukkan oleh anak-anak ayam yang selalu patuh dengan nasehat ibunya, sedangkan karakter jahat diperankan keluarga Lubak yang serakah, loba.</p> 
						<p>Dewasa ini, tradisi mesatua Bali sudah sangat jarang berkumandang bahkan di desa-desa sekalipun. Hal ini tidak mengherankan, seiring kemajuan zaman dan teknologi, anak-anak sudah dapat menonton TV, video dan lainnya. Tak jarang, tontonan audio visual tersebut, malah berefek negatif terhadap perkembangan masa tumbuh anak baik secara fisik maupun psikologis. Tengok saja, kasus-kasus smack down, pelecehan seksual, pencabulan dan tawuran antar remaja, diakui atau tidak ini adalah salah satu efek domino dari siaran-siaran kekerasan dan seksualitas yang berlebihan di media. </p>
						<p>Di Bali, cuman segelintir orang yang kini peduli dengan tradisi satua Bali. Mereka dapat di hitung dengan jari. Sebut saja, Made Taro. Lelaki yang konsen membina sanggarnya, Teater Kukuruyuk ini, begitu bersahaja dalam membina anak-anak dengan permainan tradisional dan cerita rakyat.</p>
						<p>Apa Sich Keunggulan Tradisi Mesatua?</p>
						<p>Secara umum, tradisi mesatua Bali yang dituturkan oleh para orang tua pada anaknya akan terlihat dari perilaku anak tersebut sehari-harinya, apalagi ditambah dengan gaya bertutur yang baik, diterima anak, ada respon dari mereka maka akan ber-efek pada kemampuan mentalnya dalam membedakan baik dan buruk. Jadi saran penulis, seiring perkembangan zaman, anak-anak zaman sekarang, harus sering-sering diberikan cerita-cerita yang menggugah kesadaran mereka akan pentingnya cinta kasih terhadap sesama dan mahluk lainnya. Tidak menjadi soal apabila cerita-cerita itu disisipi dengan cerita tentang tontonan yang ngetren sekarang, seperti dora emon, Sun Gokhu, Dora, dan lain-lainya.</p>
						<p>Salam Mesatua Bali,</p>	
						<h5 class="push_4 grid_6 omega">Dikutip dari: <a href="http://dwijasuastana.blogspot.co.id/2009/05/tradisi-mesatua-bali-kearifan-lokal-nan.html" target="_blank">dwijasuastana.blogspot.co.id</a></h5>
					</article>
								</div>
							<h5 class="push_4 grid_6">Dikutip dari: <a href="http://balidulo.blogspot.co.id/2013/10/kebudayaan-bali-zaman-dulu.html" target="_blank">balidulo.blogspot.co.id</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>