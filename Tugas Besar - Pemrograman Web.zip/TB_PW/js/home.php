<?php
session_start();

if ($_SESSION["nama"]=="")
{
	header('Location: index.php');
}

include "koneksi.php";

echo '
<html>
<head>
<style type="text/css">
<!--
@import url("css/style.css");
-->
</style>
</head>
<body>
';

$query = mysql_query("select * from user");

echo '<h1>Selamat Datang '.$_SESSION["nama"].' <a href="logout.php">logout</a></h1>';

echo '<table id="rounded-corner">';
echo ' <thead><tr>
<th scope="col" class="rounded-company">Id</th>
<th scope="col" class="rounded-q1">Username</th>
<th scope="col" class="rounded-q2">Password</th>
<th scope="col" class="rounded-q3">Keterangan</th>
<th scope="col" class="rounded-q3"></th>
<th scope="col" class="rounded-q4"></th>
</tr> </thead>
<tfoot>
    	<tr>
        	<td colspan="5" class="rounded-foot-left"><em></em></td>
        	<td class="rounded-foot-right">&nbsp;</td>
        </tr>
    </tfoot>


';

while ($hasil = mysql_fetch_array($query))
{
echo "<tr><td>".$hasil[0]."</td><td>".$hasil[1]."</td><td>".$hasil[2]."</td><td>".$hasil[3]."</td><td>
".'
<form method="POST" action="update.php">
<input type="hidden" name="id" value="'.$hasil[0].'">
<input type="hidden" name="username" value="'.$hasil[1].'">
<input type="hidden" name="password" value="'.$hasil[2].'">
<input type="hidden" name="keterangan" value="'.$hasil[3].'">
<input type="submit" class="button" value="Edit">
</form></td><td>
<form method="POST" action="delete.php">
<input type="hidden" name="id" value="'.$hasil[0].'">
<input type="submit" class="button" value="Hapus">
</form>
'."</td><tr>";
}
echo "</table>";

echo '
<form method="POST" class="elegant-aero" action="input.php">
<label><span>id :</span></label><input type="text"  name="id"><br/>
<label><span>username :</span></label><input type="text" name="username"><br/>
<label><span>password :</span></label><input type="password" name="password"><br/>
<label><span>keterangan :</span></label><input type="text" name="keterangan"><br/>
<input type="submit" class="button" value="Masukan Data">
</form>
';



echo '
</body>
</html>
';
?>