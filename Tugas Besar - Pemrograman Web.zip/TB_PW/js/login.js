/*LOGIN FORM*/
 $(document).ready(function(){ 
     $(".login-stuff").hide(); 
	 $(".login-stuff").css('z-index', -1);
 });
 
 $(document).ready(function(){
   $(".login-click").toggle(function(){
	 $(".login-stuff").css('z-index', 1);
     $(".login-stuff").animate({ height: 'show', opacity: 'show' }, 'slow');
   },function(){
     $(".login-stuff").animate({ height: 'hide', opacity: 'hide' }, 'slow');
   });
 });
 



