/*LOGOUT FORM*/
 $(document).ready(function(){ 
     $(".logout-stuff").hide(); 
	 $(".logout-stuff").css('z-index', -1);
 });
 
 $(document).ready(function(){
   $(".logout-click").toggle(function(){
	 $(".logout-stuff").css('z-index', 1);
     $(".logout-stuff").animate({ height: 'show', opacity: 'show' }, 'slow');
   },function(){
     $(".logout-stuff").animate({ height: 'hide', opacity: 'hide' }, 'slow');
   });
 });
 