<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<h3>Alat Pembajak Sawah</h3>
									<img src="img/bajak-sawah.jpg" alt="bajak-sawah.jpg">
									<p>Keunikan Budaya Bali dan Pesatnya Pariwisata Bali kita tidak bisa terlepas dari sebuah dunia yang disebut Pertanian Bali. Pertanian di bali memiliki pertalian yang erat antara Budaya, Agama, Alam Bali dan Pariwisata di Bali. “metekap” adalah istilah orang Bali dalam  membajak sawah mereka, peralatan tradisional yang mereka pakai terdiri dari "UGA" ditaruh pada leher kedua ekor sapi yang kemudian di ikat pada "TENGALA" dan "LAMPIT" yang berfungsi untuk membajak sawah. Seiring perkembangan jaman dan teknologi kegiatan “matekap” sudah mulai ditinggalkan oleh masyarakat Bali, karena dengan kemajuan teknologi yang menghasilkan alat pembajak sawah yang disebut dengan “Traktor” telah menggantikan alat-alat tradisional Bali. Dengan “traktor” pekerjaan membajak sawah menjadi lebih mudah dan cepat. Dengan adanya alat moderen inilah masyarakat menjadi lebih dimannjakan, dan mulai meninggalkan budaya “matekap”.</p>
									<br/>
							<h5 class="push_4 grid_6">Dikutip dari: <a href="http://balidulo.blogspot.co.id/2013/10/kebudayaan-bali-zaman-dulu.html" target="_blank">balidulo.blogspot.co.id</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>