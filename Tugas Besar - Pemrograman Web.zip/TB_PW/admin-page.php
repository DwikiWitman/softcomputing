<?php
session_start();

/*	Utk cek nama user yg login, 
	jika belum login, ke redirect ke halaman index,
	jika sudah login, tetap di admin-page (gak masuk if) 
*/
if (!isset($_SESSION["name"]))
{
	header('Location: index.php');
}

/*	cek koneksi apakah tersambung database sql nya /tidak */
include "koneksi.php";

/* buat html di php dgn echo, pertama deklarasikan css n grid yg dipakai */
echo '
<html>

<head>
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/table.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
</head>

<body>
';

/*	buat query utk select nama user di database */
$query = mysql_query("select * from user");


/*buat tabel utk menyajikan data ke user */
echo '<!--LOGOUT CARD CLICK-->
		<div class="container_12">
			<div class="push_4">
				<div class="logout-card" style="margin-left: 40px; z-index: 1; margin-top: 120px;">
					<form method="POST" action="logout.php"> 
						<input type="submit" name="logout" value="Logout">
					</form>
				</div>
			</div>
		</div>';
echo '		
<div class="container_12">
	<div class="push_3 grid_6">
		<table id="rounded-corner">';
echo ' 	
		<thead>
			<tr>
				<th scope="col">Id</th>
				<th scope="col">Username</th>
				<th scope="col">Password</th>
				<th scope="col">Keterangan</th>
				<th scope="col">Operasi Edit</th>
				<th scope="col">Operasi Hapus</th>
			</tr> 
		</thead>		
';

/*	buat perulangan untuk mengambil semua data dan dijadikan bentuk array, dgn query tadi (query tadi untuk ambil datanya) */
while ($hasil = mysql_fetch_array($query))
{
	echo
		"<tr>
			<!--tampil data-->
			<td>".$hasil[0]."</td>
			<td>".$hasil[1]."</td>
			<td>".$hasil[2]."</td>
			<td>".$hasil[3]."</td>
			<td>".'
				<!--update data-->
				<form method="POST" action="update.php">
					<input type="hidden" name="id" value="'.$hasil[0].'">
					<input type="hidden" name="username" value="'.$hasil[1].'">
					<input type="hidden" name="password" value="'.$hasil[2].'">
					<input type="hidden" name="keterangan" value="'.$hasil[3].'">
					<input type="submit" class="button" value="Edit">
				</form>
			</td>
			<td>
				<!--hapus data-->
				<form method="POST" action="delete.php">
					<input type="hidden" name="id" value="'.$hasil[0].'">
					<input type="submit" class="button" value="Hapus">
				</form>'."
			</td>
		<tr>";
}
echo '	
		</table>
	</div>
</div>

<div class="clear"> </div>
	';

/*	Untuk input data ke database */
echo '<br/>
	<div class="container_12">
		<div class="push_3 grid_6">
			<form method="POST" class="elegant-aero" action="input.php">
				<h1>Insert Data</h1>
				<label class="grid_1"><span>Id</span></label>
				<input class="grid_2" type="text"  name="id"><br/>
				<div class="clear"> </div>
				
				<label class="grid_1"><span>Username</span></label>
				<input class="grid_2" type="text" name="username"><br/>
				<div class="clear"> </div>
				
				<label class="grid_1"><span>Password</span></label>
				<input class="grid_2" type="password" name="password"><br/>
				<div class="clear"> </div>
				
				<label class="grid_1"><span>Status</span></label>
				<input class="grid_2" type="text" name="Status"><br/>
				<div class="clear"> </div>
				
				<input type="submit" class="button" value="Masukan Data">
				<div class="clear"> </div>
			</form>
		<div class="grid_12">
	</div>
';


echo '
</body>
</html>
';
?>