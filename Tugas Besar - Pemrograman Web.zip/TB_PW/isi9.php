<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<h3>Pantai Balangan</h3>
							<img src="img/balangan.jpg" alt="balangan.jpg">
							<p>Saat Pantai Dreamland sudah dipenuhi resor dan tak lagi sepi, para peselancar melangkahkan kaki mereka ke Balangan. Hamparan pasir putih terbentang, bersih dan hampir tak ada sampah. Warung - warung di sepanjang tepinya menyajikan mie instan, bir dingin, juga menyewakan kursi berjemur. </p>
							<p>Aktivitas yang bisa dilakukan di sini tentu saja berselancar, karena ombak yang menabrak tepian pantainya serupa dengan Dreamland. Anda juga bisa berenang, bermain pasir, atau berjemur di kursi untuk menikmati pemandangan indah. Namun berhati - hatilah, karena terdapat karang di beberapa tempat. Reef shoes sebaiknya digunakan. </p>
							<p>Dari Kuta, ambillah arah menuju Bypass Ngurah Rai hingga lewat Nusa Dua, lalu belok ke arah Uluwatu 10 menit kemudian. Siapkan kedua mata Anda dalam kondisi awas akan adanya papan penunjuk jalan ke arah Balangan.</p>
						
							<h5 class="push_4 grid_6">Dikutip dari: <a href="http://www.belantaraindonesia.org/2012/06/6-pantai-tersembunyi-di-bali.html" target="_blank">http://www.belantaraindonesia.org</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>