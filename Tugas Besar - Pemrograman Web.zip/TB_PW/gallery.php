
<!DOCTYPE html> 
<html>
<head>
		<title>Bali Cak Culture</title>
		<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
		<script src="js/jquery-1.3.2.min.js"></script>
		<script src="js/login.js"></script>
		<script src="js/logout.js"></script>
</head>
	
<body>
		<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		
		<!---MENU NAVIGASI TEMPAT HOME, GALLERY DAN ABOUT---->
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="index.php">About</a>
					</li>
					<li>
						<a href="index.php">Gallery</a>
					</li>
					<li>
							<?php
								session_start();
								if (!isset($_SESSION["name"]))
								{	/*Untuk menampilkan kata login*/
									echo '<a href="#" class="login-click">Login</a>';			
								}
								else
								{   /*Untuk menampilkan Selamat datang dan nama user yg sedang login*/
									echo '<a href="#" class="logout-click" style="padding: 15px 40px;">Selamat Datang, ' .$_SESSION["name"]. ' !' . '</a>';
								}
							?>
					</li>
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
		
		<!--LOGIN CARD CLICK-->
		<div class="container_12">
			<div class="push_9">
				<!--PHP yg ada alert js untuk memberi alert bahwa user/pass salah -->
				<?php
					if (isset($_SESSION["error"]) && isset($_SESSION["error"])!="" )
					{
						echo	'<script type="text/javascript">' .
									'alert("' .$_SESSION["error"]. '");' . 	
								'</script>';
						/* PHP bisa menampilkan alert gagal login, pakai echo abis tu pake js...*/
								
						session_unset(); 	/* unset semua session,  kalo unset dgn  $_SESSION["error"]=""	 masih bug dia -__-  */
					}	
				?>
				<!-- Form login yg bisa dihide dishow -->
				<div class="login-card login-stuff">	
					<!--Form Login User-->
					<form method="POST" action="check-login-user.php"> 
						<input type="text" name="username" placeholder="Username">
						<input type="password" name="password" placeholder="Password">				
						<input type="submit" name="login" value="Login">
					</form>
					
					<!--Form Login Admin-->
					<a href="login-admin.php">Login to Admin Page >></a>					
				</div>				
			</div>
		</div>
		
		<!--LOGOUT CARD CLICK-->
		<div class="container_12">
			<div class="push_9">
				<div class="logout-card logout-stuff">
					<form method="POST" action="login-admin.php"> 
						<input type="submit" name="<?php echo $_SESSION["name"]; ?>" value="View Admin Page">
					</form>
					<form method="POST" action="logout.php"> 
						<input type="submit" name="logout" value="Logout">
					</form>
				</div>
			</div>
		</div>
	
		<!--SLIDER TEMPAT ANIMASI SLIDE GAMBAR ---->
		<div class="container_12">
			<!-- Slider -->
			<div class="slider">
				<ul>
					<li>
						<img src="img/bali.jpg">	
					</li>
				</ul>					
			</div>
		</div>
		<div class="clear"></div>
		
		<!--TEMPAT KONTEN/ISI CULTURE BALI YANG TERLUPAKAN---->
		<div class="container_12 wrap">
					<!--TILES 1---->
					<div class="grid_3 tiles">
						<img src="images/ogoh-ogoh.jpg" width="200" height="200" alt="ogoh-ogoh">
						<div class="go-top">
							
						</div>
					</div>
					
					<!--TILES 2---->
					<div class="grid_3 tiles">
						<img src="images/omed.jpg" width="200" height="200" alt="Omed-omedan">
						<div class="go-top">
							
							
						</div>
					</div>
					
					<!--TILES 3---->
					<div class="grid_3 tiles">
						<img src="images/siap-selem.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
					
					<!--TILES 4---->
					<div class="grid_3 tiles">
						<img src="images/ngaben.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
		</div>
		
	<div class="clear"> </div>
	
	<div class="container_12 wrap">
					<!--TILES 1---->
					<div class="grid_3 tiles">
						<img src="img/subak.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
					
					<!--TILES 2---->
					<div class="grid_3 tiles">
						<img src="img/permainan.jpg" width="200" height="200" alt="Omed-omedan">
						<div class="go-top">
							
							
						</div>
					</div>
					
					<!--TILES 3---->
					<div class="grid_3 tiles">
						<img src="img/bajak-sawah.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
					
					<!--TILES 4---->
					<div class="grid_3 tiles">
						<img src="img/rujak-kuah-pindang.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
		</div>
		
	<div class="clear"> </div>
	
	<div class="container_12 wrap">
					<!--TILES 1---->
					<div class="grid_3 tiles">
						<img src="img/balangan.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
					
					<!--TILES 2---->
					<div class="grid_3 tiles">
						<img src="img/ungasan.jpg" width="200" height="200" alt="Omed-omedan">
						<div class="go-top">
							
							
						</div>
					</div>
					
					<!--TILES 3---->
					<div class="grid_3 tiles">
						<img src="img/amed.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
					
					<!--TILES 4---->
					<div class="grid_3 tiles">
						<img src="img/geger.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
		</div>
		
	<div class="clear"> </div>
	
	<div class="container_12 wrap">
					<!--TILES 1---->
					<div class="grid_3 tiles">
						<img src="img/sapi.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
					
					<!--TILES 2---->
					<div class="grid_3 tiles">
						<img src="img/tari-sakral.jpg" width="200" height="200" alt="Omed-omedan">
						<div class="go-top">
							
							
						</div>
					</div>
					
					<!--TILES 3---->
					<div class="grid_3 tiles">
						<img src="img/balinese-caste-system.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
					
					<!--TILES 4---->
					<div class="grid_3 tiles">
						<img src="img/balinese-caste-system.jpg" width="200" height="200" alt="Siap-selem">
						<div class="go-top">
							
						</div>
					</div>
		</div>
		
	<div class="clear"> </div>
	
	<!--FOOTER TEMPAT ABOUT---->
	<div id="about" class="container_12 footer">
			<div class="grid_6">
				<h3>
					Created by:
					<br/>				
					<br/>Yohanes Dwiki Witman (140707748).
					<br/>Widodo  (140707763).
				</h3>
			</div>
				
			<div class="grid_6" style="text-align: justify;">
				<p>	
					<em>"Website dibuat 'tiles' sehingga terlihat simpel. Konten beberapa dibuat sendiri dan diambil dari website lain. Best viewed in Chrome, beberapa bagian mungkin belum terlihat sempurna di browser lainnya!"
					</em>
				</p>
			</div>
	</div>
	<div class="clear"> </div>
</body>
</html>