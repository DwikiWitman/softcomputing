<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Bali Cak Culture</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/960_12_col.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<script src="js/jquery-1.3.2.min.js"></script>
	<script src="js/login.js"></script>
	<script src="js/logout.js"></script>
	<link rel="stylesheet" href="css/960_header.css" />
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	
</head>
<body>
<!---HEADER TEMPAT LAMBANG---->
		<div class="container_12">
			<div class="header">
				<div class="grid_3">	
					<!---lambang bali cak---->
						<a href="index.php">
							<img src="images/barong.png" height="120" width="400" alt="Logo" title="Logo">
						</a>
				</div>
			</div>
		</div>
		<div class="clear"> </div>
		<div class="container_12">			
			<div class="menu">
				<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
					<li>
						<a href="gallery.php">Gallery</a>
					</li>
					
				</ul>
			</div>
		</div>
		<div class="clear"> </div>
	
	
	<!--container untuk header content-->
	<div class="container_12_header_fixed">
			<!--Ruang kosong utk fixed header-->
			<div class="masthead">
			</div>
			<!--Ruang navigasi konten-->
			
			<!--Ruang isi konten-->
			<div class="mainContent grid_12 ">
				
				
				<!--ARTIKEL 1><-->
				<div id="content1">
					<article>
						
							<div>
								
								<h3>Pantai Ungasan</h3>
							<img src="img/ungasan.jpg" alt="ungasan.jpg">
							<p>Pantai yang terletak di wilayah paling selatan Pulau Bali ini didaulat sebagai salah satu pantai tercantik. Inilah pantai yang jadi tempat berdirinya Nammos Beach Club, salah satu kelab paling tersohor di Pulau Dewata. Untuk menikmati pantai ini, Anda harus merogoh kocek Rp 250 ribu sebagai tiket masuk, yang bisa digunakan seluruhnya untuk membeli makan dan minum.</p>
							<p>Pantai tercantik, benarkah? Argumen ini boleh diadu ketika Anda menyaksikannya sendiri. Bentangan pasir putih diterpa ombak kecil dari lautan berwarna biru jernih. Melihat pantai ini dari Nammos Beach Club akan mengingatkan Anda tentang pantai - pantai di sekeliling Laut Mediterania. Cantik!</p>
							<p>Selain Nammos Beach Club, Pantai Ungasan hanya bisa diakses kalau Anda menginap di Karma Kandara Resort atau Banyan Tree Resort. Dua resor ini persis berdiri di sebelah Nammos Beach Club. Selain berenang, kegiatan yang paling digemari wisatawan tentu saja berjemur sambil menyeruput koktail segar!</p>
						
							<h5 class="push_4 grid_6">Dikutip dari: <a href="http://www.belantaraindonesia.org/2012/06/6-pantai-tersembunyi-di-bali.html" target="_blank">http://www.belantaraindonesia.org</a></h5>
					</article>
				</div>
				<div class="clear"></div>
				
				
				
				
				
			</div>
			
			
			
	</div> 
</body>
</html>