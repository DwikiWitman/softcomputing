/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strategy;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class FlyNoWay implements FlyBehavior{
    public void fly(){
        System.out.println("I can't fly!");
    }
}
