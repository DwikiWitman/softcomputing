/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.kereta;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class kereta_api {
    String nomor_ka;
    String nama_ka;
    private int jumlah_tempat_duduk;
    private String jam_berangkat;
    private String jam_tiba;
    private String id_jurusan;

    public kereta_api() {
    }

    public kereta_api(String nomor_ka, String nama_ka, int jumlah_tempat_duduk, String jam_berangkat, String jam_tiba, String id_jurusan) {
        this.nomor_ka = nomor_ka;
        this.nama_ka = nama_ka;
        this.jumlah_tempat_duduk = jumlah_tempat_duduk;
        this.jam_berangkat = jam_berangkat;
        this.jam_tiba = jam_tiba;
        this.id_jurusan = id_jurusan;
    }

    public kereta_api(String nama_ka, int jumlah_tempat_duduk, String jam_berangkat, String jam_tiba, String id_jurusan) {
        this.nama_ka = nama_ka;
        this.jumlah_tempat_duduk = jumlah_tempat_duduk;
        this.jam_berangkat = jam_berangkat;
        this.jam_tiba = jam_tiba;
        this.id_jurusan = id_jurusan;
    }

    

    public String getNomor_ka() {
        return nomor_ka;
    }

    public void setNomor_ka(String nomor_ka) {
        this.nomor_ka = nomor_ka;
    }

    public String getNama_ka() {
        return nama_ka;
    }

    public void setNama_ka(String nama_ka) {
        this.nama_ka = nama_ka;
    }

    /**
     * @return the jumlah_tempat_duduk
     */
    public int getJumlah_tempat_duduk() {
        return jumlah_tempat_duduk;
    }

    /**
     * @param jumlah_tempat_duduk the jumlah_tempat_duduk to set
     */
    public void setJumlah_tempat_duduk(int jumlah_tempat_duduk) {
        this.jumlah_tempat_duduk = jumlah_tempat_duduk;
    }

    /**
     * @return the jam_berangkat
     */
    public String getJam_berangkat() {
        return jam_berangkat;
    }

    /**
     * @param jam_berangkat the jam_berangkat to set
     */
    public void setJam_berangkat(String jam_berangkat) {
        this.jam_berangkat = jam_berangkat;
    }

    /**
     * @return the jam_tiba
     */
    public String getJam_tiba() {
        return jam_tiba;
    }

    /**
     * @param jam_tiba the jam_tiba to set
     */
    public void setJam_tiba(String jam_tiba) {
        this.jam_tiba = jam_tiba;
    }

    /**
     * @return the id_jurusan
     */
    public String getId_jurusan() {
        return id_jurusan;
    }

    /**
     * @param id_jurusan the id_jurusan to set
     */
    public void setId_jurusan(String id_jurusan) {
        this.id_jurusan = id_jurusan;
    }
    
}
