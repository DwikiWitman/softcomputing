/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.penumpang;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class penumpang {
    private String id_penumpang;
    private String nama_penumpang;
    private String kategori;
    private String no_identitas;

    public penumpang() {
    }

    public penumpang(String nama_penumpang, String kategori, String no_identitas) {
        this.nama_penumpang = nama_penumpang;
        this.kategori = kategori;
        this.no_identitas = no_identitas;
    }

    
    public penumpang(String id_penumpang, String nama_penumpang, String kategori, String no_identitas) {
        this.id_penumpang = id_penumpang;
        this.nama_penumpang = nama_penumpang;
        this.kategori = kategori;
        this.no_identitas = no_identitas;
    }

    /**
     * @return the id_penumpang
     */
    public String getId_penumpang() {
        return id_penumpang;
    }

    /**
     * @param id_penumpang the id_penumpang to set
     */
    public void setId_penumpang(String id_penumpang) {
        this.id_penumpang = id_penumpang;
    }

    /**
     * @return the nama_penumpang
     */
    public String getNama_penumpang() {
        return nama_penumpang;
    }

    /**
     * @param nama_penumpang the nama_penumpang to set
     */
    public void setNama_penumpang(String nama_penumpang) {
        this.nama_penumpang = nama_penumpang;
    }

    /**
     * @return the kategori
     */
    public String getKategori() {
        return kategori;
    }

    /**
     * @param kategori the kategori to set
     */
    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    /**
     * @return the no_identitas
     */
    public String getNo_identitas() {
        return no_identitas;
    }

    /**
     * @param no_identitas the no_identitas to set
     */
    public void setNo_identitas(String no_identitas) {
        this.no_identitas = no_identitas;
    }

    
   
    
}
