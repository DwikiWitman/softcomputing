/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.jurusan.*;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class JurusanDAO extends ConnectionDAO implements Cruds<jurusan>{
    
    //Mendapatkan seluruh data yang ada di table Jurusan. 
    public ArrayList<jurusan> getAllJurusan() {
        ArrayList<jurusan> data = new ArrayList<>();
        String sql = "SELECT j.id_jurusan ID, a.nama_stasiun||' ('||a.kota||')' ASAL, b.nama_stasiun||' ('||b.kota||')' TUJUAN, j.tarif TARIF FROM jurusan j JOIN asal_ka a ON j.id_asal = a.id_asal JOIN tujuan_ka b ON j.id_tujuan = b.id_tujuan";
        
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    jurusan j = new jurusan(rs.getString("ID"), rs.getString("ASAL"), rs.getString("TUJUAN"),rs.getDouble("TARIF"));
                    data.add(j);
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    //Mendapatkan sebagian data untuk ditampilkan ke combobox jurusan
    public ArrayList<String> getComboBoxJurusan() {
        ArrayList<String> data = new ArrayList<>();
        String sql = "SELECT j.id_jurusan ID_JURUSAN, a.nama_stasiun||' ('||a.kota||')' ASAL, b.nama_stasiun||' ('||b.kota||')' TUJUAN FROM jurusan j JOIN asal_ka a ON j.id_asal = a.id_asal JOIN tujuan_ka b ON j.id_tujuan = b.id_tujuan";
        System.out.println("Running data fetching process...");
        String s = "";
        
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    s= "ID_"+rs.getString("ID_JURUSAN")+":"+" "+rs.getString("ASAL") + "  -  " +rs.getString("TUJUAN");
                    data.add(s);
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    
    //CRUDS
    public void insert(jurusan J) {
        String sql = "INSERT INTO jurusan (id_asal, id_tujuan, tarif) VALUES ( ? , ?, ? )";
        System.out.println("Inserting jurusan...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(J.getId_asal()) );
            ps.setString(2, String.valueOf(J.getId_tujuan()) );
            ps.setString(3, String.valueOf(J.getTarif()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Inserted " + result + " jurusan\n");
            ps.close();
            state.close();           
        } catch (Exception Ex) {
            System.out.println("Error inserting jurusan...\n");
            System.out.println(Ex);
        }
    }
    
    public void update(jurusan J) {
        String sql = "UPDATE jurusan SET id_asal = ?, id_tujuan = ?, tarif = ? WHERE id_jurusan = ?" ;
        System.out.println("Updating jurusan...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(J.getId_asal()) );
            ps.setString(2, String.valueOf(J.getId_tujuan()) );
            ps.setString(3, String.valueOf(J.getTarif()) );
            ps.setString(4, String.valueOf(J.getId_jurusan()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Updated " + result + " penumpang\n");
            ps.close();
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error updating penumpang...\n");
            System.out.println(Ex);
        }
    }

    public void delete(String key) {
        String sql = "DELETE FROM jurusan WHERE id_jurusan = ?";
        System.out.println("Deleting penumpang...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(key));
            ps.executeUpdate();
          
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Delete " + result + " penumpang succeded...");
            ps.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error deleting penumpang...");
            System.out.println(EX);
        }
    }
    
    public List<jurusan> search(String key) {
        String sql = "SELECT j.id_jurusan ID, a.nama_stasiun||' ('||a.kota||')' ASAL, b.nama_stasiun||' ('||b.kota||')' TUJUAN, j.tarif TARIF FROM jurusan j JOIN asal_ka a ON j.id_asal = a.id_asal JOIN tujuan_ka b ON j.id_tujuan = b.id_tujuan"+     
                " WHERE (j.id_jurusan Like " + "'%"+key+"%')" + 
                " OR (a.nama_stasiun||' ('||a.kota||')' Like '%" + key + "%')" + 
                " OR (b.nama_stasiun||' ('||b.kota||')' Like '%" + key + "%')" + 
                " OR (j.tarif Like '%" + key + "%')";
        System.out.println("Daftar Penumpang...");
        List<jurusan> list = new ArrayList<jurusan>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    jurusan j = new jurusan(rs.getString("ID"), rs.getString("ASAL"), rs.getString("TUJUAN"),rs.getDouble("TARIF"));
                    list.add(j);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }

        return list;
    }

}
