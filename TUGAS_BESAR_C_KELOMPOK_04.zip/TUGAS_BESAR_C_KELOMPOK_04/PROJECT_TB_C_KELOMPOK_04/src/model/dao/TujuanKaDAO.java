/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;
import java.sql.PreparedStatement;
import model.jurusan.*;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class TujuanKaDAO extends ConnectionDAO implements Cruds<tujuan_ka>{
       
    public ArrayList<tujuan_ka> getAllTujuanKa() {
        String sql = "SELECT id_tujuan, nama_stasiun, kota FROM tujuan_ka";
        ArrayList<tujuan_ka> list = new ArrayList<tujuan_ka>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    tujuan_ka t = new tujuan_ka(rs.getString("id_tujuan"), rs.getString("nama_stasiun"), rs.getString("kota"));
                    list.add(t);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }
        return list;
    }  

    public ArrayList<String> getComboBoxTujuanKa() {
        ArrayList<String> data = new ArrayList<>();
        String sql = "SELECT id_tujuan ID_TUJUAN, nama_stasiun||' ('||kota||')' CONCAT_STASIUN_KOTA FROM tujuan_ka";
        String s = "";
        System.out.println("Running data fetching process...");

        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    s= "ID_"+rs.getString("ID_TUJUAN")+":"+" "+rs.getString("CONCAT_STASIUN_KOTA");
                    data.add(s);
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public String CekIDTujuanFromJurusan  (String id_tujuan)    {
        String data = "";
        String sql = "SELECT j.id_tujuan TUJUAN FROM jurusan j JOIN asal_ka a ON j.id_tujuan = a.id_tujuan WHERE j.id_tujuan = "+Integer.parseInt(id_tujuan);
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data = rs.getString("TUJUAN");
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    //CRUDS
    public void insert(tujuan_ka A) {
        String sql = "INSERT INTO tujuan_ka (nama_stasiun, kota) VALUES (?,?)";
        System.out.println("Inserting tujuan kereta api...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(A.getNama_stasiun()));
            ps.setString(2, new String(A.getKota()));
            ps.executeUpdate();

            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Inserted " + result + " tujuan kereta api\n");
            ps.close();
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error inserting penumpang...\n");
            System.out.println(Ex);
        }
    }

    public void update(tujuan_ka t) {
        String sql = "UPDATE tujuan_ka SET nama_stasiun = ?, kota = ? WHERE id_tujuan = ?";
        System.out.println("Updating asal ka...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(t.getNama_stasiun()));
            ps.setString(2, new String(t.getKota()));
            ps.setString(3, new String(t.getId_tujuan()) );
            ps.executeUpdate();

            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Updated " + result + " tujuan ka\n");
            ps.close();
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error updating tujuan ka...\n");
            System.out.println(Ex);
        }
    }

    public void delete(String key) {
        String sql = "DELETE FROM tujuan_ka WHERE id_tujuan = ?";
        System.out.println("Deleting tujuan ka...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(key));
            ps.executeUpdate();

            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Delete " + result + " tujuan ka succeded...");
            ps.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error deleting tujuan ka...");
            System.out.println(EX);
        }
    }
    
    public List<tujuan_ka> search(String key) {
        String sql = "SELECT id_tujuan, nama_stasiun, kota FROM tujuan_ka WHERE (nama_stasiun LIKE " + "'%"+key+"%')" + " OR (kota Like '%" + key + "%')";
        List<tujuan_ka> list = new ArrayList<tujuan_ka>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    tujuan_ka t = new tujuan_ka(rs.getString("id_tujuan"), rs.getString("nama_stasiun"), rs.getString("kota"));
                    list.add(t);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }

        return list;
    }
}
