/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.util.ArrayList;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class ListDAO{
    public PenumpangDAO penumpangDao = new PenumpangDAO();
    public JurusanDAO   jurusanDao = new JurusanDAO();
    public KelasKaDAO kelaskaDao = new KelasKaDAO();
    public AsalKaDAO asalkaDAO = new AsalKaDAO();
    public TujuanKaDAO tujuankaDAO = new TujuanKaDAO();
    public TiketDAO tiketDao = new TiketDAO();
    public KeretaApiDAO keretaDAO = new KeretaApiDAO();
    public PetugasDAO petugasDAO = new PetugasDAO();
    public LoginDAO loginDao = new LoginDAO();
}
