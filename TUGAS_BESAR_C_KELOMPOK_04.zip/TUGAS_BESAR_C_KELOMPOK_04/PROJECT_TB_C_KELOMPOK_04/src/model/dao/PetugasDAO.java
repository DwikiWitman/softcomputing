/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.petugas.*;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class PetugasDAO extends ConnectionDAO implements Cruds<petugas>{
    
    //Mendapatkan seluruh data yang ada di table Jurusan. 
    public ArrayList<petugas> getAllPetugas() {
        ArrayList<petugas> data = new ArrayList<>();
        String sql = "SELECT p.id_pegawai ID, p.username USER, p.password PASS, r.nama_role ROLE FROM pegawai p JOIN role r ON p.id_role = r.id_role";
        
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    petugas p = new petugas(rs.getString("ID"), rs.getString("USER"), rs.getString("PASS"),rs.getString("ROLE"));
                    data.add(p);
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
   
    //CRUDS
    public void insert(petugas J) {
        String sql = "INSERT INTO pegawai (username, password, id_role) VALUES ( ? , ?, ? )";
        System.out.println("Inserting petugas...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(J.getUsername()) );
            ps.setString(2, String.valueOf(J.getPassword()) );
            ps.setString(3, String.valueOf(J.getId_role()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Inserted " + result + " petugas\n");
            ps.close();
            state.close();           
        } catch (Exception Ex) {
            System.out.println("Error inserting petugas...\n");
            System.out.println(Ex);
        }
    }
    
    public void update(petugas J) {
        String sql = "UPDATE pegawai SET username = ?, password = ?, id_role = ? WHERE id_pegawai = ?" ;
        System.out.println("Updating jurusan...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(J.getUsername()) );
            ps.setString(2, String.valueOf(J.getPassword()) );
            ps.setString(3, String.valueOf(J.getId_pegawai()) );
            ps.setString(4, String.valueOf(J.getId_pegawai()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Updated " + result + " penumpang\n");
            ps.close();
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error updating penumpang...\n");
            System.out.println(Ex);
        }
    }

    public void delete(String key) {
        String sql = "DELETE FROM pegawai WHERE id_pegawai = ?";
        System.out.println("Deleting penumpang...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(key));
            ps.executeUpdate();
          
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Delete " + result + " penumpang succeded...");
            ps.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error deleting penumpang...");
            System.out.println(EX);
        }
    }
    
    public List<petugas> search(String key) {
        String sql = "SELECT p.id_pegawai ID, p.username USER, p.password PASS, r.nama_role ROLE FROM pegawai p JOIN role r ON p.id_role = r.id_role"+
                " WHERE (p.id_pegawai Like " + "'%"+key+"%')" + 
                " OR (p.username Like '%" + key + "%')" + 
                " OR (p.password Like '%" + key + "%')" + 
                " OR (r.nama_role Like '%" + key + "%')";
        System.out.println("Daftar Penumpang...");
        List<petugas> list = new ArrayList<petugas>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    petugas p = new petugas(rs.getString("ID"), rs.getString("USER"), rs.getString("PASS"),rs.getString("ROLE"));
                    list.add(p);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }

        return list;
    }

}
