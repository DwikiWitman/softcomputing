/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import model.jurusan.*;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class AsalKaDAO extends ConnectionDAO implements Cruds<asal_ka>{

    public ArrayList<asal_ka> getAllAsalKa() {
        String sql = "SELECT id_asal, nama_stasiun, kota FROM asal_ka";
        ArrayList<asal_ka> list = new ArrayList<asal_ka>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    asal_ka a = new asal_ka(rs.getString("id_asal"), rs.getString("nama_stasiun"), rs.getString("kota"));
                    list.add(a);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }
        return list;
    }
    
    public ArrayList<String> getComboBoxAsalKa() {
        ArrayList<String> data = new ArrayList<>();
        String sql = "SELECT id_asal ID_ASAL, nama_stasiun||' ('||kota||')' CONCAT_STASIUN_KOTA FROM asal_ka";
        String s = "";
        System.out.println("Running data fetching process...");

        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    s= "ID_"+rs.getString("ID_ASAL")+":"+" "+rs.getString("CONCAT_STASIUN_KOTA");
                    data.add(s);
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public String CekIDAsalFromJurusan  (String id_asal)    {
        String data = "";
        String sql = "SELECT j.id_asal ASAL FROM jurusan j JOIN asal_ka a ON j.id_asal = a.id_asal WHERE j.id_asal = "+Integer.parseInt(id_asal);
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data = rs.getString("ASAL");
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    //CRUDS
    public void insert(asal_ka A) {
        String sql = "INSERT INTO asal_ka (nama_stasiun, kota) VALUES (?,?)";
        System.out.println("Inserting asal kereta api...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(A.getNama_stasiun()));
            ps.setString(2, new String(A.getKota()));
            ps.executeUpdate();

            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Inserted " + result + " asal kereta api\n");
            ps.close();
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error inserting penumpang...\n");
            System.out.println(Ex);
        }
    }

    public void update(asal_ka A) {
        String sql = "UPDATE asal_ka SET nama_stasiun = ?, kota = ? WHERE id_asal = ?";
        System.out.println("Updating asal ka...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(A.getNama_stasiun()));
            ps.setString(2, new String(A.getKota()));
            ps.setString(3, new String(A.getId_asal_ka()) );
            ps.executeUpdate();

            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Updated " + result + " asal ka\n");
            ps.close();
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error updating asal ka...\n");
            System.out.println(Ex);
        }
    }

    public void delete(String key) {
        String sql = "DELETE FROM asal_ka WHERE id_asal = ?";
        System.out.println("Deleting asal ka...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(key));
            ps.executeUpdate();

            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Delete " + result + " asal ka succeded...");
            ps.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error deleting asal ka...");
            System.out.println(EX);
        }
    }
    
    public List<asal_ka> search(String key) {
        String sql = "SELECT id_asal, nama_stasiun, kota FROM asal_ka WHERE (nama_stasiun LIKE " + "'%"+key+"%')" + " OR (kota Like '%" + key + "%')";
        List<asal_ka> list = new ArrayList<asal_ka>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    asal_ka a = new asal_ka(rs.getString("id_asal"), rs.getString("nama_stasiun"), rs.getString("kota"));
                    list.add(a);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }

        return list;
    }
}
