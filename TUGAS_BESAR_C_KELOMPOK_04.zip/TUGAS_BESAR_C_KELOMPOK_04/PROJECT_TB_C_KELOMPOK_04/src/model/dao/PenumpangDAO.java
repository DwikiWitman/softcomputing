/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import model.dao.ConnectionDAO.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.penumpang.penumpang;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class PenumpangDAO extends ConnectionDAO implements Cruds<penumpang>{

    public List<penumpang> getAllPenumpang(){
        String sql="SELECT id_penumpang, nama_penumpang, kategori, nomor_identitas FROM penumpang";
        System.out.println("Daftar Penumpang...");
        List<penumpang> list=new ArrayList<penumpang>();
        try{
            Statement statement=super.con.createStatement();
            ResultSet rs=statement.executeQuery(sql);
            if(rs!=null){
                while(rs.next()){
                    penumpang p= new penumpang(rs.getString("id_penumpang"), rs.getString("nama_penumpang"),rs.getString("kategori"),rs.getString("nomor_identitas"));
                    list.add(p);
                }
            }
            rs.close();
            statement.close();
        }
        catch(Exception Ex){
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }
         return list;
    }
    

    //CRUDS
    public void insert(penumpang P) {
        String sql = "INSERT INTO penumpang (nama_penumpang, kategori, nomor_identitas) VALUES (?,?,?)";
        System.out.println("Inserting penumpang...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(P.getNama_penumpang()) );
            ps.setString(2, new String(P.getKategori()) );
            ps.setString(3, new String(P.getNo_identitas()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Inserted " + result + " penumpang\n");
            ps.close();
            state.close();           
        } catch (Exception Ex) {
            System.out.println("Error inserting penumpang...\n");
            System.out.println(Ex);
        }
    }
    
    public void update(penumpang P) {
        String sql = "UPDATE penumpang SET nama_penumpang = ?, kategori = ?, nomor_identitas = ? WHERE id_penumpang = ?" ;
        System.out.println("Updating penumpang...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(P.getNama_penumpang()) );
            ps.setString(2, new String(P.getKategori()) );
            ps.setString(3, new String(P.getNo_identitas()) );
            ps.setString(4, new String(P.getId_penumpang()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Updated " + result + " penumpang\n");
            ps.close();
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error updating penumpang...\n");
            System.out.println(Ex);
        }
    }

    public void delete(String key) {
        String sql = "DELETE FROM penumpang WHERE id_penumpang = ?";
        System.out.println("Deleting penumpang...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(key));
            ps.executeUpdate();
          
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Delete " + result + " penumpang succeded...");
            ps.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error deleting penumpang...");
            System.out.println(EX);
        }
    }
    
    public List<penumpang> search(String key) {
        String sql = "SELECT id_penumpang,nama_penumpang,kategori,nomor_identitas FROM penumpang WHERE (id_penumpang Like '%" + key + "%') OR (nama_penumpang Like '%" + key + "%')" + " OR (kategori Like '%" + key + "%')" + " OR (nomor_identitas Like '%" + key + "%')";
        System.out.println("Daftar Penumpang...");
        List<penumpang> list = new ArrayList<penumpang>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    penumpang p = new penumpang(rs.getString("id_penumpang"), rs.getString("nama_penumpang"), rs.getString("kategori"), rs.getString("nomor_identitas"));
                    list.add(p);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }

        return list;
    }
    
}
