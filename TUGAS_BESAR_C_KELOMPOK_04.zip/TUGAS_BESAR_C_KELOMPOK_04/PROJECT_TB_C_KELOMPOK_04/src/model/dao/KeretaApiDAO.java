/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.kereta.kereta_api;
/**
 *
 * @author Balianda
 */
public class KeretaApiDAO extends ConnectionDAO{
    public ArrayList<kereta_api> getAllKeretaApi() {
        ArrayList<kereta_api> data = new ArrayList<>();
        String sql = "SELECT k.nomor_ka NOMOR_KA, k.nama_ka NAMA_KA, k.jumlah_tempat_duduk JUMLAH_TEMPAT_DUDUK, k.jam_berangkat JAM_BERANGKAT, k.jam_tiba JAM_TIBA, 'ID_'||k.id_jurusan||': '||a.nama_stasiun||'('||a.kota||')' ||' - '|| b.nama_stasiun||'('||b.kota||')' JURUSAN  FROM kereta_api k JOIN jurusan j ON k.id_jurusan=j.id_jurusan JOIN asal_ka a ON j.id_asal = a.id_asal JOIN tujuan_ka b ON j.id_tujuan = b.id_tujuan ";
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    kereta_api K = new kereta_api(rs.getString("NOMOR_KA"), rs.getString("NAMA_KA"), rs.getInt("JUMLAH_TEMPAT_DUDUK"),rs.getString("JAM_BERANGKAT"),rs.getString("JAM_TIBA"),rs.getString("JURUSAN"));
                    data.add(K);
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public String getIDKeretaApiFromTiket(String nomor_ka)    {
        String data = "";
        String sql = "SELECT t.nomor_ka NOMOR_KA FROM tiket t JOIN kereta_api k ON t.nomor_ka = k.nomor_ka WHERE t.nomor_ka = '"+nomor_ka+"'";
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data = rs.getString("NOMOR_KA");
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public void insert(kereta_api K) {
        String sql = "INSERT INTO kereta_api (nama_ka, jumlah_tempat_duduk, jam_berangkat, jam_tiba, id_jurusan) VALUES (?,?,?,?,?)";
        System.out.println("Inserting jurusan...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(K.getNama_ka()) );
            ps.setString(2, String.valueOf(K.getJumlah_tempat_duduk()) );
            ps.setString(3, new String(K.getJam_berangkat()) );
            ps.setString(4, new String(K.getJam_tiba()) );
            ps.setString(5, new String(K.getId_jurusan()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Inserted " + result + " kereta api\n");
            ps.close();
            state.close();           
        } catch (Exception Ex) {
            System.out.println("Error inserting kereta api...\n");
            System.out.println(Ex);
        }
    }
    
    public void update(kereta_api K) {
        String sql = "UPDATE kereta_api SET nama_ka = '"+K.getNama_ka()+"', jumlah_tempat_duduk = "+K.getJumlah_tempat_duduk()+", jam_berangkat = '"+K.getJam_berangkat()+"', jam_tiba = '"+K.getJam_tiba()+"', id_jurusan = "+K.getId_jurusan()+" WHERE nomor_ka = "+Integer.parseInt(K.getNomor_ka()) ;
        System.out.println("Updating kereta...");
        try {            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Updated " + result + " kereta\n");
            
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error updating kereta...\n");
            System.out.println(Ex);
        }
    }
    
    public void delete(String key) {
        String sql = "DELETE FROM kereta_api WHERE nomor_ka = ?";
        System.out.println("Deleting kereta...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(key));
            ps.executeUpdate();
          
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Delete " + result + " kereta succeded...");
            ps.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error deleting kereta...");
            System.out.println(EX);
        }
    }
    
    public List<kereta_api> search(String key) {
        String sql = "SELECT k.nomor_ka NOMOR_KA, k.nama_ka NAMA_KA, k.jumlah_tempat_duduk JUMLAH_TEMPAT_DUDUK, k.jam_berangkat JAM_BERANGKAT, k.jam_tiba JAM_TIBA, 'ID_'||k.id_jurusan||': '||a.nama_stasiun||'('||a.kota||')' ||' - '|| b.nama_stasiun||'('||b.kota||')' JURUSAN  FROM kereta_api k JOIN jurusan j ON k.id_jurusan=j.id_jurusan JOIN asal_ka a ON j.id_asal = a.id_asal JOIN tujuan_ka b ON j.id_tujuan = b.id_tujuan "+
                " WHERE (k.nomor_ka = " + Integer.parseInt(key) + ")"+
                " OR (k.nama_ka Like " + "'%"+key+"%')" +
                " OR (k.jumah_tempat_duduk = " + Integer.parseInt(key) + ")";
        System.out.println("Daftar Kereta Api...");
        List<kereta_api> list = new ArrayList<kereta_api>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    kereta_api j = new kereta_api(rs.getString("NOMOR_KA"), rs.getString("NAMA_KA"), rs.getInt("JUMLAH_TEMPAT_DUDUK"),rs.getString("JAM_BERANGKAT"),rs.getString("JAM_TIBA"),rs.getString("JURUSAN"));
                    list.add(j);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }

        return list;
    }
}
