/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.jurusan;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class tujuan_ka {
    String id_tujuan;
    String nama_stasiun;
    String kota;

    public tujuan_ka() {
    }

    public tujuan_ka(String nama_stasiun, String kota) {
        this.nama_stasiun = nama_stasiun;
        this.kota = kota;
    }

    public tujuan_ka(String id_tujuan, String nama_stasiun, String kota) {
        this.id_tujuan = id_tujuan;
        this.nama_stasiun = nama_stasiun;
        this.kota = kota;
    }

    public String getId_tujuan() {
        return id_tujuan;
    }

    public void setId_tujuan(String id_tujuan) {
        this.id_tujuan = id_tujuan;
    }

    public String getNama_stasiun() {
        return nama_stasiun;
    }

    public void setNama_stasiun(String nama_stasiun) {
        this.nama_stasiun = nama_stasiun;
    }

    public String getKota() {
        return kota;
    }

    public void setKota(String kota) {
        this.kota = kota;
    }

   
}
