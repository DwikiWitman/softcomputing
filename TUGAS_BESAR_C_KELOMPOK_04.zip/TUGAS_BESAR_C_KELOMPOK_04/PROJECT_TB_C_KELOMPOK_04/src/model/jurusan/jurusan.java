/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.jurusan;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class jurusan {

    String id_jurusan;
    String id_asal;
    String id_tujuan;
    
    asal_ka asal;
    tujuan_ka tujuan;
    
    double tarif;

    public jurusan() {
    }

    public jurusan(String id_asal, String id_tujuan, double tarif) {
        this.id_asal = id_asal;
        this.id_tujuan = id_tujuan;
        this.tarif = tarif;
    }

    public jurusan(String id_jurusan, String id_asal, String id_tujuan, double tarif) {
        this.id_jurusan = id_jurusan;
        this.id_asal = id_asal;
        this.id_tujuan = id_tujuan;
        this.tarif = tarif;
    }

    public jurusan(String id_jurusan, String id_asal, String id_tujuan, asal_ka asal, tujuan_ka tujuan, double tarif) {
        this.id_jurusan = id_jurusan;
        this.id_asal = id_asal;
        this.id_tujuan = id_tujuan;
        this.asal = asal;
        this.tujuan = tujuan;
        this.tarif = tarif;
    }

    public String getId_jurusan() {
        return id_jurusan;
    }

    public void setId_jurusan(String id_jurusan) {
        this.id_jurusan = id_jurusan;
    }

    public String getId_asal() {
        return id_asal;
    }

    public void setId_asal(String id_asal) {
        this.id_asal = id_asal;
    }

    public String getId_tujuan() {
        return id_tujuan;
    }

    public void setId_tujuan(String id_tujuan) {
        this.id_tujuan = id_tujuan;
    }

    public asal_ka getAsal() {
        return asal;
    }

    public void setAsal(asal_ka asal) {
        this.asal = asal;
    }

    public tujuan_ka getTujuan() {
        return tujuan;
    }

    public void setTujuan(tujuan_ka tujuan) {
        this.tujuan = tujuan;
    }

    public double getTarif() {
        return tarif;
    }

    public void setTarif(double tarif) {
        this.tarif = tarif;
    }

    
}
