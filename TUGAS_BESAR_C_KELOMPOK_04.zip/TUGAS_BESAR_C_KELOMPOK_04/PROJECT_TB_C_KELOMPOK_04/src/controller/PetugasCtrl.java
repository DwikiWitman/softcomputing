/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import model.dao.*;
import javax.swing.table.TableModel;
import model.penumpang.*;
import model.tiket.*;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class PetugasCtrl {
    
    ListDAO myDao = new ListDAO();
    
    public ArrayList<String> GetComboBoxKelasKA(){
        ArrayList<String> data = new ArrayList<>();
        myDao.kelaskaDao.makeConnection();
        data = myDao.kelaskaDao.getNamaKelasKA();
        myDao.kelaskaDao.closeConnection();
        return data;
    }
    
    public ArrayList<String> GetComboBoxJurusan(){
        ArrayList<String> data = new ArrayList<>();
        myDao.jurusanDao.makeConnection();
        data = myDao.jurusanDao.getComboBoxJurusan();
        myDao.jurusanDao.closeConnection();
        return data;
    }
    
    public void InsertPenumpang(penumpang p){
        myDao.penumpangDao.makeConnection();
        myDao.penumpangDao.insert(p);
        myDao.penumpangDao.closeConnection();
    }
    
    public void DeletePenumpang(String key){
        myDao.penumpangDao.makeConnection();
        myDao.penumpangDao.delete(key);
        myDao.penumpangDao.closeConnection();
    }
    
    public void UpdatePenumpang(penumpang p){
        myDao.penumpangDao.makeConnection();
        myDao.penumpangDao.update(p);
        myDao.penumpangDao.closeConnection();
    }
    
    public TableModel displayAllPenumpang(){
       myDao.penumpangDao.makeConnection();
       TableModel modelPenumpang = new TablePenumpang(myDao.penumpangDao.getAllPenumpang());
       myDao.penumpangDao.closeConnection();
       return modelPenumpang;
    }
    
    public TableModel displaySearchPenumpang(String key){
       myDao.penumpangDao.makeConnection();
       TableModel modelPenumpang = new TablePenumpang(myDao.penumpangDao.search(key));
       myDao.penumpangDao.closeConnection();
       return modelPenumpang;
    }
    
    
    public void InsertTiket(tiket p){
        myDao.tiketDao.makeConnection();
        myDao.tiketDao.insert(p);
        myDao.tiketDao.closeConnection();
    }
    
    public void DeleteTiket(String key){
        myDao.tiketDao.makeConnection();
        myDao.tiketDao.delete(key);
        myDao.tiketDao.closeConnection();
    }
    
    public void UpdateTiket(tiket p){
        myDao.tiketDao.makeConnection();
        myDao.tiketDao.update(p);
        myDao.tiketDao.closeConnection();
    }
    
    public TableModel displayAllTiket(){
       myDao.tiketDao.makeConnection();
       TableModel modelTiket = new TableTiket(myDao.tiketDao.getAllTiket());
       myDao.tiketDao.closeConnection();
       return modelTiket;
    }
    
    public TableModel displaySearchTiket(String key){
       myDao.tiketDao.makeConnection();
       TableModel modelTiket = new TableTiket(myDao.tiketDao.search(key));
       myDao.tiketDao.closeConnection();
       return modelTiket;
    }
    
    public String GetIDKeretaApi(String id_jurusan){
        String data = "";
        myDao.tiketDao.makeConnection();
        data = myDao.tiketDao.getIDKeretaApi(id_jurusan);
        myDao.tiketDao.closeConnection();
        return data;
    } 
    
    public String GetIDKelasKa(String nama_kelas){
        String data = "";
        myDao.tiketDao.makeConnection();
        data = myDao.tiketDao.getIDKelasKa(nama_kelas);
        myDao.tiketDao.closeConnection();
        return data;
    } 
    
    public String GetIDPenumpang(penumpang p){
        String data = "";
        myDao.tiketDao.makeConnection();
        data = myDao.tiketDao.getNewIDPenumpang(p);
        myDao.tiketDao.closeConnection();
        return data;
    } 
    
    public int CekTempatDuduk(String nomor_duduk){
        int data = 0;
        myDao.tiketDao.makeConnection();
        data = myDao.tiketDao.cekTempatDuduk(nomor_duduk);
        myDao.tiketDao.closeConnection();
        return data;
    } 
    
    public String CekIdentitas(String identitas){
        String data = "";
        myDao.tiketDao.makeConnection();
        data = myDao.tiketDao.cekIdentitas(identitas);
        myDao.tiketDao.closeConnection();
        return data;
    } 
    
    public String GetHargaJurusan(String id_jurusan){
        String data = "";
        myDao.tiketDao.makeConnection();
        data = myDao.tiketDao.getHargaJurusan(id_jurusan);
        myDao.tiketDao.closeConnection();
        return data;
    }
    
    public void UpdateJumlahTempatDuduk(String nomor_ka){
        myDao.tiketDao.makeConnection();
        myDao.tiketDao.updateJumlahTempatDuduk(nomor_ka);
        myDao.tiketDao.closeConnection();
    }

    
}
