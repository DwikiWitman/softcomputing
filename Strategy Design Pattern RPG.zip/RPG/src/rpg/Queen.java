/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Queen extends Character{

    public Queen() {
        weapon = new BowAndArrowBehavior();
    }
    
    public void fight(){
        System.out.println("Queen's now fighting!");
        weapon.useWeapon();
    }
}
