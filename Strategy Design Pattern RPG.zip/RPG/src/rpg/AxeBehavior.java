/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class AxeBehavior implements WeaponBehavior{
    public void useWeapon(){
        System.out.println("using Axe!");
    }
}
