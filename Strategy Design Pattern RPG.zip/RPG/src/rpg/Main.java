/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Character Char = new King();
        Char.fight();
        System.out.println("Damage deals is too weak!");
        System.out.println("Change weapon!");
        Char.setWeapon(new SwordBehavior());
        Char.fight(); System.out.println("");
        System.out.println("But i want to deal a huge damage!");
        System.out.println("Change weapon!");
        Char.setWeapon(new AxeBehavior());
        Char.fight(); System.out.println("");
        
        System.out.println("Too late, your character's dead!");
        System.out.println("Change character!"); 
        System.out.println("");
        Char = new Queen();
        Char.fight();
        System.out.println("Damage deals is too weak bro!");
        System.out.println("Change weapon!");
        Char.setWeapon(new KnifeBehavior());
        Char.fight();
        
        System.out.println("Victory, the game is set !");
    }
    
}
