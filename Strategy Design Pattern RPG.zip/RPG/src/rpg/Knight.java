/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Knight extends Character{

    public Knight() {
        weapon = new SwordBehavior();
    }
      
    public void fight(){
        System.out.println("Knight's now fighting!");
        weapon.useWeapon();
    }
}
