/*
 * Main.java
 *
 * Created on November 27, 2013, 10:44 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package composite;
import java.util.*;

/**
 *
 * @author Sony Vaio
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
                Composite Dekan=new Composite("Dekan");
		Composite Wadek1=new Composite("Wadek1");
		Composite Wadek2=new Composite("Wadek2");
		Composite Wadek3=new Composite("Wadek3");
		Composite Keuangan=new Composite("Keuangan");
                Primitive P1 = new Primitive("Student Staaf 3");

		Dekan.addChild(Wadek1);
                Dekan.addChild(Wadek2);
                Dekan.addChild(Wadek3);
                
                Wadek2.addChild(Keuangan);
                Keuangan.addChild(P1);
                Keuangan.addChild(new Primitive("Student Staff4"));

		Wadek3.addChild(new Primitive("StudentStaff1"));
		Wadek3.addChild(new Primitive("StudentStaff2"));

	
		Dekan.traverse();
    }
    
}

abstract class Pegawai
{
	public abstract void traverse();
}

class Composite extends Pegawai
{
	private Pegawai[] child= new Pegawai[9];
	private int total=0;
	private String Role;

	public Composite(String Role)
	{
		this.Role=Role;
	}


	public void addChild(Pegawai child)
	{
		this.child[total++]=child;
	}

	public void traverse()
	{
		System.out.print("(" + Role + ")");
		for (int i=0;i < total; i++)
		{
					child[i].traverse();
					System.out.println();
		}
	}
}



class Primitive extends Pegawai
{
	private String Role;

	public Primitive(String Role)
	{
		this.Role=Role;
	}

	public void traverse()
	{
		System.out.print(": primitive->(" + Role + ")");
	}
}



