/*
 * Main.java
 *
 * Created on May 13, 2014, 10:06 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javaapplication30;

/**
 *
 * @author Sony Vaio
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ShapeFactory shapeFactory = new ShapeFactory();

      //get an object of Circle and call its draw method.
      Shape shape1 = shapeFactory.getShape("CIRCLE");

      //call draw method of Circle
      shape1.draw();

      //get an object of Rectangle and call its draw method.
      Shape shape2 = shapeFactory.getShape("RECTANGLE");

      //call draw method of Rectangle
      shape2.draw();

      //get an object of Square and call its draw method.
      Shape shape3 = shapeFactory.getShape("SQUARE");

      //call draw method of circle
      shape3.draw();
    }
  
}

interface Shape {
   void draw(); }
    
    
   class Rectangle implements Shape {
       // @Override
        public void draw() {
        System.out.println("Inside Rectangle::draw() method.");
        }
    }
    
 class Square implements Shape {
        //@Override
        public void draw() {
        System.out.println("Inside Square::draw() method.");
        }
    }
    
    class Circle implements Shape {
       // @Override
        public void draw() {
        System.out.println("Inside Circle::draw() method.");
        }
    }
    
    class ShapeFactory {
     //use getShape method to get object of type shape 
     public Shape getShape(String shapeType)
     {
      if(shapeType == null){
         return null;
      }	
      
      if(shapeType.equalsIgnoreCase("CIRCLE")){
         return new Circle();
      } 
      else if(shapeType.equalsIgnoreCase("RECTANGLE")){
         return new Rectangle();
      } 
      else if(shapeType.equalsIgnoreCase("SQUARE")){
         return new Square();
      }
      return null;
   }
}
