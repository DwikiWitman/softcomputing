/*
 * Main.java
 *
 * Created on November 27, 2013, 10:34 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package factory;
import java.util.*;

/**
 *
 * @author Sony Vaio
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
                Namer namer= new Namer();
		NameFactory nfactory = new NameFactory();
		String sFirstName, sLastName;

		//send the text to the factory and get a class back
		namer = nfactory.getNamer("Vai, Steve");
		//compute the first and last names using the returned class
		sFirstName = namer.getFirst();
		sLastName = namer.getLast();

		System.out.println("First Name : " + sFirstName);
		System.out.println("Last Name : " + sLastName);
    }
    
}

class Namer
{ //a simple class to take a string apart into two names
	protected String last; //store last name here
	protected String first; //store first name here
	public String getFirst() {
		return first; //return first name
	}
	public String getLast() {
		return last; //return last name
	}
}



class FirstFirst extends Namer
{
	public FirstFirst(String s) {
		int i = s.lastIndexOf(" "); 	//find sep space
		if (i > 0) {
			first = s.substring(0, i).trim(); //left is first name
			last =s.substring(i+1).trim(); //right is last name
		} else {
			first =""; // put all in last name
			last = s; // if no space
		}
	}
}

class LastFirst extends Namer
{ //split last, first
    public LastFirst(String s)
    {
	int i = s.indexOf(","); //find comma
	 if (i > 0)
	{
		last = s.substring(0, i).trim(); //left is last name
		first = s.substring(i + 1).trim(); //right is first name
	}
	else
	{
		last = s; // put all in last name
		first = ""; // if no comma
	}
   }
}


class NameFactory
{
	//returns an instance of LastFirst or FirstFirst
	//depending on whether a comma is found
	public Namer getNamer(String entry)
	{
	   int i = entry.indexOf(","); //comma determines name order
	   if (i>0)
	       return new LastFirst(entry); //return one class
	   else
	      return new FirstFirst(entry); //or the other
	}
}

