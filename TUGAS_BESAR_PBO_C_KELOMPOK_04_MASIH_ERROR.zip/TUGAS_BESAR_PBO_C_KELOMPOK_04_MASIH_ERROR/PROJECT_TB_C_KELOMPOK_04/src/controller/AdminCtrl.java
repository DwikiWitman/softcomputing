/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import java.util.List;
import model.dao.*;
import javax.swing.table.TableModel;
import model.jurusan.TableJurusan;
import model.jurusan.*;
import model.kereta.*;
import model.penumpang.*;
import model.petugas.*;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class AdminCtrl {

    ListDAO myDao = new ListDAO();
    public PetugasCtrl petugasControl = new PetugasCtrl();
 

//CONTROL CRUD JURUSAN    
    public void InsertJurusan(jurusan p) {
        myDao.jurusanDao.makeConnection();
        myDao.jurusanDao.insert(p);
        myDao.jurusanDao.closeConnection();
    }

    public void DeleteJurusan(String key) {
        myDao.jurusanDao.makeConnection();
        myDao.jurusanDao.delete(key);
        myDao.jurusanDao.closeConnection();
    }

    public void UpdateJurusan(jurusan p) {
        myDao.jurusanDao.makeConnection();
        myDao.jurusanDao.update(p);
        myDao.jurusanDao.closeConnection();
    }
    
    public ArrayList<String> GetComboBoxJurusan() {
        ArrayList<String> data = new ArrayList<>();
        myDao.jurusanDao.makeConnection();
        data = myDao.jurusanDao.getComboBoxJurusan();
        myDao.jurusanDao.closeConnection();
        return data;
    }

    public TableModel displayAllJurusan() {
        myDao.jurusanDao.makeConnection();
        TableModel modelJurusan = new TableJurusan(myDao.jurusanDao.getAllJurusan());
        myDao.jurusanDao.closeConnection();
        return modelJurusan;
    }

    public TableModel displaySearchJurusan(String key) {
        myDao.jurusanDao.makeConnection();
        TableModel modelJurusan = new TableJurusan(myDao.jurusanDao.search(key));
        myDao.jurusanDao.closeConnection();
        return modelJurusan;
    }
  
    
    
//CONTROL CRUD Asal KA     
    public void InsertAsalKa(asal_ka a) {
        myDao.asalkaDAO.makeConnection();
        myDao.asalkaDAO.insert(a);
        myDao.asalkaDAO.closeConnection();
    }

    public void DeleteAsalKa(String key) {
        myDao.asalkaDAO.makeConnection();
        myDao.asalkaDAO.delete(key);
        myDao.asalkaDAO.closeConnection();
    }

    public void UpdateAsalKa(asal_ka a) {
        myDao.asalkaDAO.makeConnection();
        myDao.asalkaDAO.update(a);
        myDao.asalkaDAO.closeConnection();
    }
    
    public String CekIDAsalFromJurusan  (String id_asal){
        String data = "";
        myDao.asalkaDAO.makeConnection();
        data = myDao.asalkaDAO.CekIDAsalFromJurusan(id_asal);
        myDao.jurusanDao.closeConnection();
        return data;
    }
    
    public String CekIDTujuanFromJurusan  (String id_tujuan){
        String data = "";
        myDao.asalkaDAO.makeConnection();
        data = myDao.tujuankaDAO.CekIDTujuanFromJurusan(id_tujuan);
        myDao.jurusanDao.closeConnection();
        return data;
    }
      
    public ArrayList<String> GetComboBoxAsal() {
        ArrayList<String> data = new ArrayList<>();
        myDao.asalkaDAO.makeConnection();
        data = myDao.asalkaDAO.getComboBoxAsalKa();
        myDao.jurusanDao.closeConnection();
        return data;
    }

    public TableModel displayAllAsalKa() {
        myDao.asalkaDAO.makeConnection();
        TableModel modelAsalKa = new TableAsalKA(myDao.asalkaDAO.getAllAsalKa());
        myDao.asalkaDAO.closeConnection();
        return modelAsalKa;
    }

    public TableModel displaySearchAsalKa(String key) {
        myDao.asalkaDAO.makeConnection();
        TableModel modelAsalKa = new TableAsalKA(myDao.asalkaDAO.search(key));
        myDao.asalkaDAO.closeConnection();
        return modelAsalKa;
    }
    
    
   

//CONTROL CRUD Tujuan KA     
    public void InsertTujuanKa(tujuan_ka a) {
        myDao.tujuankaDAO.makeConnection();
        myDao.tujuankaDAO.insert(a);
        myDao.tujuankaDAO.closeConnection();
    }

    public void DeleteTujuanKa(String key) {
        myDao.tujuankaDAO.makeConnection();
        myDao.tujuankaDAO.delete(key);
        myDao.tujuankaDAO.closeConnection();
    }

    public void UpdateTujuanKa(tujuan_ka a) {
        myDao.tujuankaDAO.makeConnection();
        myDao.tujuankaDAO.update(a);
        myDao.tujuankaDAO.closeConnection();
    }
    
    public ArrayList<String> GetComboBoxTujuan() {
        ArrayList<String> data = new ArrayList<>();
        myDao.tujuankaDAO.makeConnection();
        data = myDao.tujuankaDAO.getComboBoxTujuanKa();
        myDao.jurusanDao.closeConnection();
        return data;
    }

    public TableModel displayAllTujuanKa() {
        myDao.tujuankaDAO.makeConnection();
        TableModel modelTujuanKa = new TableTujuanKA(myDao.tujuankaDAO.getAllTujuanKa());
        myDao.tujuankaDAO.closeConnection();
        return modelTujuanKa;
    }

    public TableModel displaySearchTujuanKa(String key) {
        myDao.tujuankaDAO.makeConnection();
        TableModel modelTujuanKa = new TableTujuanKA(myDao.tujuankaDAO.search(key));
        myDao.tujuankaDAO.closeConnection();
        return modelTujuanKa;
    }
    
    
//CONTROL CRUD Kelas KA
    public void InsertKelasKa(kelas_ka a){
        myDao.kelaskaDao.makeConnection();
        myDao.kelaskaDao.insert(a);
        myDao.kelaskaDao.closeConnection();
    }
    
//CONTROL CRUD Kereta API
    public void InsertKeretaApi(kereta_api a) {
        myDao.keretaDAO.makeConnection();
        myDao.keretaDAO.insert(a);
        myDao.keretaDAO.closeConnection();
    }

    public void DeleteKeretaApi(String key) {
        myDao.keretaDAO.makeConnection();
        myDao.keretaDAO.delete(key);
        myDao.keretaDAO.closeConnection();
    }

    public void UpdateKeretaApi(kereta_api a) {
        myDao.keretaDAO.makeConnection();
        myDao.keretaDAO.update(a);
        myDao.keretaDAO.closeConnection();
    }
    
    public TableModel displayAllKeretaApi() {
        myDao.keretaDAO.makeConnection();
        TableModel modelKeretaApi = new TableKereta(myDao.keretaDAO.getAllKeretaApi());
        myDao.keretaDAO.closeConnection();
        return modelKeretaApi;
    }

    public TableModel displaySearchKeretaApi(String key) {
        myDao.keretaDAO.makeConnection();
        TableModel modelKeretaApi = new TableKereta(myDao.keretaDAO.search(key));
        myDao.keretaDAO.closeConnection();
        return modelKeretaApi;
    }
    
    public String CekIDKeretaApiFromTiket(String nomor_ka){
        String data = "";
        myDao.keretaDAO.makeConnection();
        data = myDao.keretaDAO.getIDKeretaApiFromTiket(nomor_ka);
        myDao.keretaDAO.closeConnection();
        return data;
    }

//CONTROL CRUD Petugas     
    public void InsertPetugas(petugas a) {
        myDao.petugasDAO.makeConnection();
        myDao.petugasDAO.insert(a);
        myDao.petugasDAO.closeConnection();
    }

    public void DeletePetugas(String key) {
        myDao.petugasDAO.makeConnection();
        myDao.petugasDAO.delete(key);
        myDao.petugasDAO.closeConnection();
    }

    public void UpdatePetugas(petugas a) {
        myDao.petugasDAO.makeConnection();
        myDao.petugasDAO.update(a);
        myDao.petugasDAO.closeConnection();
    }

    public TableModel displayAllPetugas() {
        myDao.petugasDAO.makeConnection();
        TableModel modelPetugas = new TablePetugas(myDao.petugasDAO.getAllPetugas());
        myDao.petugasDAO.closeConnection();
        return modelPetugas;
    }

    public TableModel displaySearchPetugas(String key) {
        myDao.petugasDAO.makeConnection();
        TableModel modelPetugas = new TablePetugas(myDao.petugasDAO.search(key));
        myDao.petugasDAO.closeConnection();
        return modelPetugas;
    }
}
