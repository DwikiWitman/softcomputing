/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.dao.LoginDAO;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class LoginCtrl {
    
    LoginDAO myDao = new LoginDAO();
    
    public int CekLogin(String user, String pass)
    {
        int data = 0;
        myDao.makeConnection();
        data = myDao.cekLogin(user, pass);
        myDao.closeConnection();
        return data;
    }
    
    public String CekRole(String user, String pass)
    {
        String data = "";
        myDao.makeConnection();
        data = myDao.cekRole(user, pass);
        myDao.closeConnection();
        return data;
    }
}
