/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.tiket;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class tiket {
    String id_tiket;
    String id_penumpang;
    String nomor_duduk;
    String nomor_ka;
    String id_kelas_ka;

    public tiket() {
    }

    public tiket(String id_penumpang, String nomor_duduk, String nomor_ka, String id_kelas_ka) {
        this.id_penumpang = id_penumpang;
        this.nomor_duduk = nomor_duduk;
        this.nomor_ka = nomor_ka;
        this.id_kelas_ka = id_kelas_ka;
    }

    public tiket(String id_tiket, String id_penumpang, String nomor_duduk, String nomor_ka, String id_kelas_ka) {
        this.id_tiket = id_tiket;
        this.id_penumpang = id_penumpang;
        this.nomor_duduk = nomor_duduk;
        this.nomor_ka = nomor_ka;
        this.id_kelas_ka = id_kelas_ka;
    }

    public String getId_tiket() {
        return id_tiket;
    }

    public void setId_tiket(String id_tiket) {
        this.id_tiket = id_tiket;
    }

    public String getId_penumpang() {
        return id_penumpang;
    }

    public void setId_penumpang(String id_penumpang) {
        this.id_penumpang = id_penumpang;
    }

    public String getNomor_duduk() {
        return nomor_duduk;
    }

    public void setNomor_duduk(String nomor_duduk) {
        this.nomor_duduk = nomor_duduk;
    }

    public String getNomor_ka() {
        return nomor_ka;
    }

    public void setNomor_ka(String nomor_ka) {
        this.nomor_ka = nomor_ka;
    }

    public String getId_kelas_ka() {
        return id_kelas_ka;
    }

    public void setId_kelas_ka(String id_kelas_ka) {
        this.id_kelas_ka = id_kelas_ka;
    }
    
    
}
