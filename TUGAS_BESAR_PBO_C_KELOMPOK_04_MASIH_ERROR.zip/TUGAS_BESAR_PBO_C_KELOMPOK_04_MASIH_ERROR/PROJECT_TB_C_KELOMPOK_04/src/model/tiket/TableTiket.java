/*
 * ModelDosen.java
 *
 * Created on June 10, 2012, 6:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package model.tiket;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author dwiki witman
 */
public class TableTiket extends AbstractTableModel {
    private List<tiket> list;
    
    /** Creates a new instance of TablePenumpang */
    
    public TableTiket( List<tiket> list) {
        this.list = list;
    }

    public int getRowCount() {
        return list.size();
    }

    public int getColumnCount() {
        return 5;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return list.get(rowIndex).getId_tiket();
            case 1:
                return list.get(rowIndex).getId_penumpang();
            case 2:
                return list.get(rowIndex).getNomor_duduk();
            case 3:
                return list.get(rowIndex).getNomor_ka();
            case 4:
                return list.get(rowIndex).getId_kelas_ka();
            
            default:
                return null;
        }
    }

    public String getColumnName(int column) {
        switch (column){
            case 0:
                return "ID Tiket";
            case 1:
                return "Nama Penumpang";   
            case 2:
                return "Nomor Duduk";   
            case 3:
                return "Nomor Kereta Api";
            case 4:
                return "Kelas Kereta Api";
            
            default:
                return null;
        }
    }
    
}
