/*
 * ModelDosen.java
 *
 * Created on June 10, 2012, 6:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package model.penumpang;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author dwiki witman
 */
public class TablePenumpang extends AbstractTableModel {
    private List<penumpang> list;
    /** Creates a new instance of TablePenumpang */
    
    public TablePenumpang( List<penumpang> list) {
        this.list = list;
    }

    public int getRowCount() {
        return list.size();
    }

    public int getColumnCount() {
        return 4;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return list.get(rowIndex).getId_penumpang();
            case 1:
                return list.get(rowIndex).getNama_penumpang();
            case 2:
                return list.get(rowIndex).getKategori();
            case 3:
                return list.get(rowIndex).getNo_identitas();
            default:
                return null;
        }
    }


    public String getColumnName(int column) {
        switch (column){
            case 0:
                return "ID Penumpang";
            case 1:
                return "Nama Penumpang";   
            case 2:
                return "Kelas";   
            case 3:
                return "Nomor KTP/SIM";
            default:
                return null;
        }
    }
    
}
