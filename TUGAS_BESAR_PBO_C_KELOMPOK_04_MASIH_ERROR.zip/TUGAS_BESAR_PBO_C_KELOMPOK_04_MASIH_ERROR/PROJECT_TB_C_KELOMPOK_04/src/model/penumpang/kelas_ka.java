/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.penumpang;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class kelas_ka {
    String id_kelas_ka;
    String nama_kelas;

    public kelas_ka() {
    }

    public kelas_ka(String id_kelas_ka, String nama_kelas) {
        this.id_kelas_ka = id_kelas_ka;
        this.nama_kelas = nama_kelas;
    }

    public String getId_kelas_ka() {
        return id_kelas_ka;
    }

    public void setId_kelas_ka(String id_kelas_ka) {
        this.id_kelas_ka = id_kelas_ka;
    }

    public String getNama_kelas() {
        return nama_kelas;
    }

    public void setNama_kelas(String nama_kelas) {
        this.nama_kelas = nama_kelas;
    }
    
}
