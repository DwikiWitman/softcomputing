/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model.xception;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Xception extends Exception{
    int index;

    public Xception() {
    }

    public Xception(int index) {
        this.index = index;
    }
    
    public String showException() throws Exception
    {
        String text = "";
        if(index==1)
        {
            text = "Lengkapi data yang masih kosong";
        }
        else if(index==2)
        {
            text = "Tanggal angkat harus terdiri dari 8 digit yaitu MMDDYYYY";
        }
        else if(index==3)
        {
            text = "Inputan nip harus 7 digit, dengan format _ _ _ . _ _ _";
        }
        
        return text;
            
    }
}
