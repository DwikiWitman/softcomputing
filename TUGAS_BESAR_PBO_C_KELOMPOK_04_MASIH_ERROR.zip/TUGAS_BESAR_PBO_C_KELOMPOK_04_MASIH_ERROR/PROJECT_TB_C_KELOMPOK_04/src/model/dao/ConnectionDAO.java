package model.dao;
import model.penumpang.penumpang;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class ConnectionDAO {
 
    public static Connection con;
        
    // Java version 7 (ODBC 64 BIT)*/ 
    public static final String url = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + "D:\\DATABASE_TB_C_KELOMPOK_04.mdb";
    //public static final String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    
    // Java version 8
    public static final String urlv8 = "jdbc:ucanaccess://"+"D:"+File.separator+"DATABASE_TB_C_KELOMPOK_04.mdb";
    //  
    
    // PENTING :    Database Access letaknya harus sesuai path yang dituliskan pada kode program ini
    //              Jika kalian tidak memiliki drive D silahkan pindah basis data anda ke drive lain (misal C atau F) dan ubah
    //              path diatas sesuai lokasi basis data anda. (misal anda memindah ke drive C maka ganti path dengan C:\\Kereta Api.mdb)
    
    public ConnectionDAO() {
    }

    public void makeConnection(){
        System.out.println("Opening database with Java version 7...");
        try
        {
            //Class.forName(driver);
            con=DriverManager.getConnection(url);
            System.out.println("Success ! \n");
        }
        catch(Exception EX)
        {
            System.out.println("Error opening the database with Java version 7...");
            System.out.println("Try opening the database with Java version 8...");
            try {
                con=DriverManager.getConnection(urlv8);
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(EX);
        }
    }
    
    public void closeConnection(){
       System.out.println("Closing database...");
        try
        {
            con.close();
            System.out.println("Success ! \n");
        }
        catch(Exception EX)
        {
            System.out.println("Error closing the database...");
            System.out.println(EX);
        }
    }
   
}
