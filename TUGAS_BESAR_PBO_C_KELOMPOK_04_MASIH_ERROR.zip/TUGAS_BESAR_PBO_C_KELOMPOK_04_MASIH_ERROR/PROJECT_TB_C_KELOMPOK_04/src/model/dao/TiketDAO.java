/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.penumpang.penumpang;
import model.tiket.*;
/**
 *
 * @author Yohanes Dwiki Witman
 */
public class TiketDAO extends ConnectionDAO implements Cruds<tiket>{
    //Mendapatkan seluruh data yang ada di table Jurusan. 
    public ArrayList<tiket> getAllTiket() {
        ArrayList<tiket> data = new ArrayList<>();
        String sql = "SELECT t.id_tiket ID, 'ID'||p.id_penumpang||':  '||p.nama_penumpang PENUMPANG, t.nomor_duduk NOMOR_DUDUK, t.nomor_ka NOMOR_KA, k.nama_kelas KELAS FROM tiket t JOIN penumpang p ON t.id_penumpang = p.id_penumpang JOIN kelas_ka k ON t.id_kelas_ka = k.id_kelas_ka";
        
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    tiket t = new tiket(rs.getString("ID"), rs.getString("PENUMPANG"), rs.getString("NOMOR_DUDUK"), rs.getString("NOMOR_KA"), rs.getString("KELAS"));
                    data.add(t);
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public String getIDKeretaApi(String id_jurusan) {
        String data="";
        
        String sql = "SELECT nomor_ka ID FROM kereta_api WHERE id_jurusan = "+Integer.parseInt(id_jurusan);
                     
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data = rs.getString("ID");
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public String getIDKelasKa(String nama_kelas) {
        String data="";
        String sql = "SELECT id_kelas_ka KELAS FROM kelas_ka  WHERE nama_kelas Like " + "'"+nama_kelas+"'" ;
                     
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data = rs.getString("KELAS");
                }
            }
            
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public String getNewIDPenumpang(penumpang p) {
        String data="";
        String sql = "SELECT p.id_penumpang ID FROM penumpang p "+
                     " WHERE (p.nama_penumpang Like " + "'%"+p.getNama_penumpang()+"%')" + 
                     " AND (p.kategori Like '%" + p.getKategori() + "%')" + 
                     " AND (p.nomor_identitas Like '%" + p.getNo_identitas() + "%')";
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data = rs.getString("ID");
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public int cekTempatDuduk(String nomor_duduk) {
        String data="";
        String sql = "SELECT nomor_duduk DUDUK FROM tiket  WHERE nomor_duduk = "+nomor_duduk;
                     
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data = rs.getString("DUDUK");
                }
            }
            
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        if(data.equals(""))
            return 1;
        else
            return 0;
    }
    
    public String cekIdentitas(String identitas) {
        String data="";
        String sql = "SELECT nomor_identitas IDENTITAS FROM penumpang  WHERE (nomor_identitas Like " + "'"+identitas+"')";
                     
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data = rs.getString("IDENTITAS");
                }
            }
            
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }
        return data;
    }
    
    public String getHargaJurusan(String id_jurusan) {
        String data="";
        String sql = "SELECT tarif FROM jurusan WHERE id_jurusan = "+id_jurusan ;
                     
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data = rs.getString("tarif");
                    System.out.println("++++++++++++METHOD1"+data);
                }
            }
            
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public String getHargaKelas(String id_kelas_ka) {
        String data="";
        String sql = "SELECT tarif FROM kelas_ka WHERE id_kelas_ka = 1" ;
        System.out.println("++++++++++++NAMAKATEGORI"+id_kelas_ka);
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    int i = rs.getInt("tarif");
                    data = String.valueOf(i);
                    System.out.println("++++++++++++METHOD KELAS"+data);
                }
            }          
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }  
        
        return data;
    }
    
    public void updateJumlahTempatDuduk(String nomor_ka){
        String sql = "UPDATE kereta_api SET jumlah_tempat_duduk = jumlah_tempat_duduk -1 WHERE nomor_ka = " + Integer.parseInt(nomor_ka);
        System.out.println("Updating tiket...");
        try {
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Updated " + result + " tiket\n");
            
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error updating tiket...\n");
            System.out.println(Ex);
        }
    }
    
    
    
    //CRUDS
    public void insert(tiket T) {
        String sql = "INSERT INTO tiket (id_penumpang, nomor_duduk, nomor_ka, id_kelas_ka) VALUES ( ?, ?, ?, ? )";
        System.out.println("Inserting tiket...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(T.getId_penumpang()) );
            ps.setString(2, String.valueOf(T.getNomor_duduk()) );
            ps.setString(3, String.valueOf(T.getNomor_ka()) );
            ps.setString(4, String.valueOf(T.getId_kelas_ka()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Inserted " + result + " tiket\n");
            ps.close();
            state.close();           
        } catch (Exception Ex) {
            System.out.println("Error inserting tiket...\n");
            System.out.println(Ex);
        }
    }
    
    public void update(tiket T) {
        String sql = "UPDATE tiket SET id_penumpang = "+T.getId_penumpang()+", nomor_duduk = "+T.getNomor_duduk()+", nomor_ka = "+T.getNomor_ka()+", id_kelas_ka = "+T.getId_kelas_ka()+"  WHERE id_tiket = "+Integer.parseInt(T.getId_tiket());
        System.out.println("Updating tiket...");
        try {
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Updated " + result + " tiket\n");
            
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error updating tiket...\n");
            System.out.println(Ex);
        }
    }

    public void delete(String key) {
        String sql = "DELETE FROM tiket WHERE id_tiket = "+Integer.parseInt(key);
        System.out.println("Deleting tiket...");
        try {
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Delete " + result + " tiket succeded...");
            state.close();
        } catch (Exception EX) {
            System.out.println("Error deleting tiket...");
            System.out.println(EX);
        }
    }
    
    public List<tiket> search(String key) {
        String sql = "SELECT t.id_tiket ID, 'ID'||p.id_penumpang||':  '||p.nama_penumpang PENUMPANG, t.nomor_duduk NOMOR_DUDUK, t.nomor_ka NOMOR_KA, k.nama_kelas KELAS FROM tiket t JOIN penumpang p ON t.id_penumpang = p.id_penumpang JOIN kelas_ka k ON t.id_kelas_ka = k.id_kelas_ka"+
                " WHERE (t.id_tiket = " + Integer.parseInt(key) + ")"+
                " OR (p.id_penumpang||':  '||p.nama_penumpang Like '%" + key + "%')" + 
                " OR (t.nomor_duduk = "+ Integer.parseInt(key) + ")" +
                " OR (t.nomor_ka = "+ Integer.parseInt(key) + ")"+ 
                " OR (k.nama_kelas Like '%" + key + "%')";
                //" WHERE p.nama_penumpang Like '%" + key + "%')";
        
        System.out.println("Daftar Tiket...");
        List<tiket> list = new ArrayList<tiket>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    tiket t = new tiket(rs.getString("ID"), rs.getString("PENUMPANG"), rs.getString("NOMOR_DUDUK"), rs.getString("NOMOR_KA"), rs.getString("KELAS"));
                    list.add(t);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }

        return list;
    }
}
