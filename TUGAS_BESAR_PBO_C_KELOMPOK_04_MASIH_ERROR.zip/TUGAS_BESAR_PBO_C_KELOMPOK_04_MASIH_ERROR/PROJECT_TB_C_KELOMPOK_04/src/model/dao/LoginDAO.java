/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import model.dao.ConnectionDAO.*;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class LoginDAO extends ConnectionDAO {
    private String username;
    private String password;
    
    public LoginDAO() {
    }

    public LoginDAO(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public int cekLogin(String user, String pass){
        String sql = "SELECT username, password FROM pegawai WHERE username = ? AND password = ?";
        System.out.println("Getting data...");
        int data = 0;
        try
        {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1,new String(user));
            ps.setString(2,new String(pass));
            
            ResultSet rs = ps.executeQuery();
            if(rs != null)
            {
                while(rs.next())
                {
                    data = 1;
                }
            }
            rs.close();
            ps.close();
        }
        catch(Exception Ex)
        {
            System.out.println("Error getting data...\n");
            System.out.println(Ex);
        }
        return data;
    } 
    
    public String cekRole(String user, String pass){
        String sql = "SELECT r.nama_role FROM pegawai p JOIN role r ON p.id_role = r.id_role WHERE p.username = ? AND p.password = ?";
        System.out.println("Getting data...");
        String data = "";
        try
        {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1,new String(user));
            ps.setString(2,new String(pass));
            
            ResultSet rs = ps.executeQuery();
            if(rs != null)
            {
                while(rs.next())
                {
                    data = rs.getString("role.nama_role");
                }
            }
            rs.close();
            ps.close();
        }
        catch(Exception Ex)
        {
            System.out.println("Error getting data...\n");
            System.out.println(Ex);
        }
        return data;
    } 
}
