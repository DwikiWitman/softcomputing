/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import model.penumpang.*;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class KelasKaDAO extends ConnectionDAO implements Cruds<kelas_ka>{
    
    public ArrayList<String> getNamaKelasKA() {
        ArrayList<String> data = new ArrayList<>();
        String sql = "SELECT nama_kelas FROM kelas_ka";
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    data.add(rs.getString("nama_kelas"));
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    public ArrayList<kelas_ka> getAllKelasKA() {
        ArrayList<kelas_ka> data = new ArrayList<>();
        String sql = "SELECT id_kelas_ka, nama_kelas FROM kelas_ka";
        System.out.println("Running data fetching process...");
        try {
            Statement state = super.con.createStatement();
            ResultSet rs = state.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    kelas_ka k = new kelas_ka(rs.getString("id_kelas_ka"), rs.getString("nama_kelas"));
                    data.add(k);
                }
            }
            rs.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error reading from database...");
            System.out.println(EX);
        }

        return data;
    }
    
    
    //CRUDS
    public void insert(kelas_ka K) {
        String sql = "INSERT INTO kelas_ka (nama_kelas) VALUES (?)";
        System.out.println("Inserting tiket...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, new String(K.getNama_kelas()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Inserted " + result + " kelas kereta api\n");
            ps.close();
            state.close();           
        } catch (Exception Ex) {
            System.out.println("Error inserting kelas kereta api...\n");
            System.out.println(Ex);
        }
    }
    
    public void update(kelas_ka K) {
        String sql = "UPDATE kelas_ka SET nama_kelas = ?  WHERE id_kelas_ka = ?" ;
        System.out.println("Updating kelas kereta api...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(K.getNama_kelas()) );
            ps.setString(2, String.valueOf(K.getId_kelas_ka()) );
            ps.executeUpdate();
            
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Updated " + result + " kelas kereta api\n");
            ps.close();
            state.close();
        } catch (Exception Ex) {
            System.out.println("Error updating kelas kereta api...\n");
            System.out.println(Ex);
        }
    }

    public void delete(String key) {
        String sql = "DELETE FROM kelas_ka WHERE id_tiket = ?";
        System.out.println("Deleting kereta api...");
        try {
            PreparedStatement ps = super.con.prepareStatement(sql);
            ps.setString(1, String.valueOf(key));
            ps.executeUpdate();
          
            Statement state = super.con.createStatement();
            int result = state.executeUpdate(sql);
            System.out.println("Delete " + result + " kereta api succeded...");
            ps.close();
            state.close();
        } catch (Exception EX) {
            System.out.println("Error deleting kereta api...");
            System.out.println(EX);
        }
    }
    
    public ArrayList<kelas_ka> search(String key) {
        String sql = "SELECT id_kelas_ka ID, nama_kelas NAMA_KELAS FROM kelas_ka" +
                " WHERE (id_kelas_ka Like " + "'%"+key+"%')" + 
                " OR (nama_kelas Like '%" + key + "%')";
        
        System.out.println("Daftar Tiket...");
        ArrayList<kelas_ka> list = new ArrayList<kelas_ka>();
        try {
            Statement statement = super.con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            if (rs != null) {
                while (rs.next()) {
                    kelas_ka k = new kelas_ka(rs.getString("ID"), rs.getString("NAMA_KELAS"));
                    list.add(k);
                }
            }
            rs.close();
            statement.close();
        } catch (Exception Ex) {
            System.out.println("Error reading database information...\n");
            System.out.println(Ex);
        }

        return list;
    }
}
