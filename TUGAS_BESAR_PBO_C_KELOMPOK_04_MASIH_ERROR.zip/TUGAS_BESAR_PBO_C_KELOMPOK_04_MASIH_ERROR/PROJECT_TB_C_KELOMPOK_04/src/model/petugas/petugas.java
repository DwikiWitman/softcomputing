/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.petugas;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class petugas {
    String id_pegawai;
    String username;
    String password;
    String id_role;

    public petugas(String username, String password, String id_role) {
        this.username = username;
        this.password = password;
        this.id_role = id_role;
    }

    public petugas(String id_pegawai, String username, String password, String id_role) {
        this.id_pegawai = id_pegawai;
        this.username = username;
        this.password = password;
        this.id_role = id_role;
    }

    public String getId_pegawai() {
        return id_pegawai;
    }

    public void setId_pegawai(String id_pegawai) {
        this.id_pegawai = id_pegawai;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getId_role() {
        return id_role;
    }

    public void setId_role(String id_role) {
        this.id_role = id_role;
    }
    
    
    
}
