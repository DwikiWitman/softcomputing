/*
 * ModelDosen.java
 *
 * Created on June 10, 2012, 6:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package model.petugas;
import model.petugas.*;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author dwiki witman
 */
public class TablePetugas extends AbstractTableModel {
    private List<petugas> list;
    /** Creates a new instance of TablePenumpang */
    
    public TablePetugas( List<petugas> list) {
        this.list = list;
    }

    public int getRowCount() {
        return list.size();
    }

    public int getColumnCount() {
        return 4;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return list.get(rowIndex).getId_pegawai();
            case 1:
                return list.get(rowIndex).getUsername();
            case 2:
                return list.get(rowIndex).getPassword();
            case 3:
                return list.get(rowIndex).getId_role();
            default:
                return null;
        }
    }


    public String getColumnName(int column) {
        switch (column){
            case 0:
                return "ID Petugas";
            case 1:
                return "Username Petugas";   
            case 2:
                return "Password";   
            case 3:
                return "Role";
            default:
                return null;
        }
    }
    
}
