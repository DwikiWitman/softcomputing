/*
 * ModelDosen.java
 *
 * Created on June 10, 2012, 6:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package model.jurusan;
import model.jurusan.*;
import model.dao.JurusanDAO;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author dwiki witman
 */
public class TableJurusan extends AbstractTableModel {
    private List<jurusan> list;
    
    /** Creates a new instance of TablePenumpang */
    
    public TableJurusan( List<jurusan> list) {
        this.list = list;
    }

    public int getRowCount() {
        return list.size();
    }

    public int getColumnCount() {
        return 4;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return list.get(rowIndex).getId_jurusan();
            case 1:
                return list.get(rowIndex).getId_asal();
            case 2:
                return list.get(rowIndex).getId_tujuan();
            case 3:
                return list.get(rowIndex).getTarif();
            default:
                return null;
        }
    }


    public String getColumnName(int column) {
        switch (column){
            case 0:
                return "ID Jurusan";
            case 1:
                return "Asal Kereta Api";   
            case 2:
                return "Tujuan Kereta Api";   
            case 3:
                return "Tarif";
            default:
                return null;
        }
    }
}
