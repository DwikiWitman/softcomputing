/*
 * ModelDosen.java
 *
 * Created on June 10, 2012, 6:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package model.jurusan;
import model.jurusan.*;
import model.dao.JurusanDAO;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author dwiki witman
 */
public class TableAsalKA extends AbstractTableModel {
    private List<asal_ka> list;
    
    /** Creates a new instance of TablePenumpang */
    
    public TableAsalKA( List<asal_ka> list) {
        this.list = list;
    }

    public int getRowCount() {
        return list.size();
    }

    public int getColumnCount() {
        return 3;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return list.get(rowIndex).getId_asal_ka();
            case 1:
                return list.get(rowIndex).getNama_stasiun();
            case 2:
                return list.get(rowIndex).getKota();
            default:
                return null;
        }
    }


    public String getColumnName(int column) {
        switch (column){
            case 0:
                return "ID Asal";
            case 1:
                return "Nama Stasiun";   
            case 2:
                return "Kota";   
            default:
                return null;
        }
    }
    
}
