/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.jurusan;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class asal_ka {

    String id_asal_ka;
    String nama_stasiun;
    String kota;

    public asal_ka() {
    }

    public asal_ka(String nama_stasiun, String kota) {
        this.nama_stasiun = nama_stasiun;
        this.kota = kota;
    }

    public asal_ka(String id_asal_ka, String nama_stasiun, String kota) {
        this.id_asal_ka = id_asal_ka;
        this.nama_stasiun = nama_stasiun;
        this.kota = kota;
    }

    public String getId_asal_ka() {
        return id_asal_ka;
    }

    public void setId_asal_ka(String id_asal_ka) {
        this.id_asal_ka = id_asal_ka;
    }

    public String getNama_stasiun() {
        return nama_stasiun;
    }

    public void setNama_stasiun(String nama_stasiun) {
        this.nama_stasiun = nama_stasiun;
    }

    public String getKota() {
        return kota;
    }

    public void setKota(String kota) {
        this.kota = kota;
    }

}
