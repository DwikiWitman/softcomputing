/*
 * ModelDosen.java
 *
 * Created on June 10, 2012, 6:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package model.kereta;
import model.kereta.*;
import model.kereta.*;
import model.dao.JurusanDAO;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author dwiki witman
 */
public class TableKereta extends AbstractTableModel {
    private List<kereta_api> list;
    
    /** Creates a new instance of TablePenumpang */
    
    public TableKereta( List<kereta_api> list) {
        this.list = list;
    }

    public int getRowCount() {
        return list.size();
    }

    public int getColumnCount() {
        return 6;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return list.get(rowIndex).getNomor_ka();
            case 1:
                return list.get(rowIndex).getNama_ka();
            case 2:
                return list.get(rowIndex).getJumlah_tempat_duduk();
            case 3:
                return list.get(rowIndex).getJam_berangkat();
            case 4:
                return list.get(rowIndex).getJam_tiba();
            case 5:
                return list.get(rowIndex).getId_jurusan();
            
            
            default:
                return null;
        }
    }


    public String getColumnName(int column) {
        switch (column){
            case 0:
                return "Nomor Kereta Api";
            case 1:
                return "Nama Kereta Api";   
            case 2:
                return "Jumlah Tempat Duduk";   
            case 3:
                return "Jam Berangkat";
            case 4:
                return "Jam Tiba";
            case 5:
                return "Jurusan";
            default:
                return null;
        }
    }
}
