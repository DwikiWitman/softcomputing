/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facedetection;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class DetectorCam {
    private CascadeClassifier cascadeClassifier;
    private MatOfRect detectedFaces;
    private Mat coloredImage;
    private Mat greyImage;
    private Settings settings;

    public DetectorCam() {
        //System.out.println(System.getProperty("java.library.path"));
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        detectedFaces = new MatOfRect();
        coloredImage = new Mat();
        greyImage = new Mat();
        cascadeClassifier = new CascadeClassifier(Settings.HAAR_CASCADE_CLASSIFIER);    
    }
    
    public Mat detectFaces(Mat inputFrame){
        inputFrame.copyTo(coloredImage);
        inputFrame.copyTo(greyImage);
        
        //This function converts an input image from one color space to another
        Imgproc.cvtColor(coloredImage, greyImage, Imgproc.COLOR_BGR2GRAY);
        
        //Equalize the histogram of a grayscale image
        Imgproc.equalizeHist(greyImage, greyImage);
        
        cascadeClassifier.detectMultiScale(greyImage, detectedFaces);
        
        showFacesOnScreen();
        
        return coloredImage;
    }

    private void showFacesOnScreen(){
        for(Rect rect : detectedFaces.toArray()){
            Core.rectangle(coloredImage, rect.tl(), rect.br(), Settings.COLOR_RGB, Settings.THICK, 8, 0);
        }
    }
}
