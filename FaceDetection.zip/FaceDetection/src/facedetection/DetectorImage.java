/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facedetection;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import org.opencv.core.Core;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.highgui.Highgui;
import java.io.File;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class DetectorImage {

    private CascadeClassifier cascadeClassifier;
    private Settings settings;

    public DetectorImage(Settings setting) {
        //System.out.println(System.getProperty("java.library.path"));
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        cascadeClassifier = new CascadeClassifier(Settings.HAAR_CASCADE_CLASSIFIER);
        this.settings = setting;
    }
    
    public void detectFaces(File file, ImagePanel imagePanel){
        Mat img = Highgui.imread(file.getAbsolutePath(), Highgui.CV_LOAD_IMAGE_COLOR);
        
        MatOfRect faceDetection = new MatOfRect();
        
        cascadeClassifier.detectMultiScale(img, faceDetection, Settings.SCALE_FACTOR, Settings.MIN_NEIGHBORS, Settings.FLAGS, Settings.MIN_SIZE, Settings.MAX_SIZE);
        
        for(Rect rect : faceDetection.toArray()){
            Core.rectangle(img, rect.tl(), rect.br(), Settings.COLOR_RGB, Settings.THICK, 8, 0);
        }
        
        BufferedImage bufferedImage = convertMatToImage(img);
        imagePanel.updateImage(bufferedImage);
    }

    public BufferedImage convertMatToImage(Mat mat){
        int type = BufferedImage.TYPE_BYTE_GRAY;
        
        if(mat.channels() > 1){
            type = BufferedImage.TYPE_3BYTE_BGR;
        }
        
        int bufferSize = mat.channels() * mat.cols() * mat.rows();
        byte[] bytes = new byte[bufferSize];
        mat.get(0, 0, bytes);
        
        BufferedImage img = new BufferedImage(mat.cols(), mat.rows(), type);
        final byte[] targetPixels = ((DataBufferByte) img.getRaster().getDataBuffer()).getData();
        System.arraycopy(bytes, 0, targetPixels, 0, bytes.length);
        
        return img;
    }
}
