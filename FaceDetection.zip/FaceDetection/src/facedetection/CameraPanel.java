/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facedetection;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import javax.swing.ImageIcon;
import org.opencv.core.Mat;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class CameraPanel {
    private BufferedImage image;

    public BufferedImage getImage() {
        return image;
    }

    public CameraPanel() {
    }
    
    public boolean convertMatToImage(Mat matBGR){
        int width = matBGR.width(), height = matBGR.height() , channels = matBGR.channels();
        byte[] sourcePixels = new byte[width * height * channels];
        matBGR.get(0, 0, sourcePixels);
        
        image = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
        final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        System.arraycopy(sourcePixels, 0, targetPixels, 0, sourcePixels.length);
        
        return true;
    }
    
}
