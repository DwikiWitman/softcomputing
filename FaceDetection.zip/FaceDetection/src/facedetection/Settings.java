/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 

DOCUMENTATION

1.) SCALE_FACTOR: close/far faces from camera
    
    value: 1.1 - 1.4
        Small -> algorithm will be slow
        High -> faster detection but risk of missing some faces

2.) MIN_NEIGHBORS: how many neighbors each candidate rectangle should have
    
    value: 3 - 6
        Higher value -> less detections but with higher quality

3.) FLAGS: kinds of heuristic (reject images region that contain no/few/many edges)
    
    value: 10 ?
        Higher value -> ?

4.) MIN_SIZE: small faces are ignored
    
    value: 30x30 [standart]

5.) MAX_SIZE: huge faces are ignored
    
    value: ? 
*/

package facedetection;
import org.opencv.core.Scalar;
import org.opencv.core.Size;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Settings {

    public Settings() {
    
    }
    
//Apps Setting
    public static final String APPLICATION_NAME = "Face Detector";
    public static final String EXIT_WARNING = "Do you want to exit?";
    public static final int FRAME_WIDTH = 800;
    public static final int FRAME_HEIGHT = 600;
    
//Algorithm Setting
    public static double SCALE_FACTOR = 4;
    public static int MIN_NEIGHBORS = 3;
    public static int FLAGS = 10 ;
    public static Size MIN_SIZE = new Size(80, 80);
    public static Size MAX_SIZE = new Size(500, 500);

//Image Setting
    public static final int SCALE_WIDTH = 800;
    public static final int SCALE_HEIGHT = 600;
    
//Rectangle Setting
    public static final Scalar COLOR_RGB = new Scalar(0, 0, 255); //red
    public static final int THICK = 2;

//XML Setting (other XML file can be found in opencv installation folder)
    public static String HAAR_CASCADE_CLASSIFIER = "C:\\opencv\\sources\\data\\haarcascades\\haarcascade_frontalface_default.xml";

    
    public static void setSCALE_FACTOR(double SCALE_FACTOR) {
        Settings.SCALE_FACTOR = SCALE_FACTOR;
    }

    public static void setMIN_NEIGHBORS(int MIN_NEIGHBORS) {
        Settings.MIN_NEIGHBORS = MIN_NEIGHBORS;
    }

    public static void setFLAGS(int FLAGS) {
        Settings.FLAGS = FLAGS;
    }

    public static void setMIN_SIZE(Size MIN_SIZE) {
        Settings.MIN_SIZE = MIN_SIZE;
    }

    public static void setMAX_SIZE(Size MAX_SIZE) {
        Settings.MAX_SIZE = MAX_SIZE;
    }

    public static void setHAAR_CASCADE_CLASSIFIER(String HAAR_CASCADE_CLASSIFIER) {
        Settings.HAAR_CASCADE_CLASSIFIER = HAAR_CASCADE_CLASSIFIER;
    }

    public static double getSCALE_FACTOR() {
        return SCALE_FACTOR;
    }

    public static int getMIN_NEIGHBORS() {
        return MIN_NEIGHBORS;
    }

    public static int getFLAGS() {
        return FLAGS;
    }

    public static Size getMIN_SIZE() {
        return MIN_SIZE;
    }

    public static Size getMAX_SIZE() {
        return MAX_SIZE;
    }

    public static String getHAAR_CASCADE_CLASSIFIER() {
        return HAAR_CASCADE_CLASSIFIER;
    }
    
    
}
