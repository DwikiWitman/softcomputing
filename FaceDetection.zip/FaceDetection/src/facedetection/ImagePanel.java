/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facedetection;

import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class ImagePanel {
    private ImageIcon transformedImageIcon; 
    
    public void updateImage(final Image img){
        transformedImageIcon = new ImageIcon(scaleImage(img));
    }
    
    private Image scaleImage(Image img) {
        return img.getScaledInstance(Settings.SCALE_WIDTH, Settings.SCALE_HEIGHT, Image.SCALE_SMOOTH);
    }
    
    public void loadImage(File file){
        this.transformedImageIcon = new ImageIcon(file.getAbsolutePath());
        updateImage(transformedImageIcon.getImage());
    }

    public ImageIcon getTransformedImageIcon() {
        return transformedImageIcon;
    }
    
}
