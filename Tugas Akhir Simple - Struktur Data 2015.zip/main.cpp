#include "header.h"

void main()
{

	int Y=4,g,nip,z=5,a=5;
	string plat;
	pegawai datapegawai;
	mobil datamobil;

	ListPegawai Pegawai;
	ListMobil Mobil; 
	ListPeminjaman Peminjaman;
	
	createEmptyPegawai (Pegawai);
	createEmptyMobil (Mobil);
	createEmptyPeminjaman (Peminjaman);
	

	loadMobil (Mobil);
	loadPegawai (Pegawai);
	loadPeminjaman (Peminjaman);
	
	gotoxy(4,3);
	setLayar(80,25);

	do
	{
		system("CLS");
		printf("\n\n\t\t\t %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",201,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,187);
		printf("\n\t\t\t %c           Menu            %c",186,186); 
		printf("\n\t\t\t %c     Input Data Pegawai    %c",186,186);
		printf("\n\t\t\t %c     Edit Data Pegawai     %c",186,186);
		printf("\n\t\t\t %c     Hapus Data Pegawai    %c",186,186);
		printf("\n\t\t\t %c     Input Data Mobil      %c",186,186);
		printf("\n\t\t\t %c     Edit Data Mobil       %c",186,186);
		printf("\n\t\t\t %c     Hapus Data Mobil      %c",186,186);
		printf("\n\t\t\t %c     Peminjaman Mobil      %c",186,186);
		printf("\n\t\t\t %c     Pengembalian Mobil    %c",186,186);
		printf("\n\t\t\t %c     Lap. Data Mobil       %c",186,186);
		printf("\n\t\t\t %c     Lap. Data Pegawai     %c",186,186);
		printf("\n\t\t\t %c     Lap. Peminjaman       %c",186,186);
		printf("\n\t\t\t %c     Lap. Satu Pegawai     %c",186,186);
		printf("\n\t\t\t %c     Lap. Jmlh Peminjaman  %c",186,186);
		printf("\n\t\t\t %c     Exit                  %c",186,186);
		printf("\n\t\t\t %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",200,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,188);
		
		//==================================================//
		////////////////////START/////////////////////////////
		////////////////////CURSOR MENU///////////////////////
		//////////////////////////////////////////////////////
		//==================================================//
		
		do
		{
			system("Color 2"); //rubah background
			//setcolor(9); //rubah kursor
			//HideCursor();
			gotoxy(27,Y);
			printf("%c",175); 
			gotoxy(51,Y);
			printf("%c",174);

			g=getch();
			nip=0;

			if(g==72)			//panah ke atas
			{	
				gotoxy(27,Y);
				printf(" ");
				gotoxy(51,Y);
				printf(" ");
					Y--;
			}
			
			if(g==80)			//panah ke bawah
			{
				gotoxy(27,Y);
				printf(" ");
				gotoxy(51,Y);
				printf(" ");
					Y++;
			}

			if(Y==3)
			{
				Y=17;
			}
			if(Y==18)
			{
				Y=4;
			}
		}while(g!=13);
		

	
		system("CLS");
		switch(Y-3)
		{
			case 1: a=5,z=5;
					
					gotoxy(3,3);printf("Nip ");gotoxy(16,3);printf("Nama");
					
					gotoxy(3,a);scanf("%d",&datapegawai.NIP);

					if(isUnikPegawai(Pegawai,datapegawai.NIP)==1)
					{
						gotoxy(17,a);fflush(stdin);gets(datapegawai.nama);
						datapegawai.jumlahPeminjaman=0;
						insertPegawai(Pegawai,datapegawai);
						savePegawai(Pegawai);
					}
					else
						Info("Sudah Ada... ");
										
					getch();
					break;

			case 2: if(!isEmptyPegawai (Pegawai))
					{
						printAllPegawai(Pegawai);
						Info("NIP: ");scanf("%d",&nip);
						
						gotoxy(49,12);editPegawai (Pegawai,nip);
						savePegawai(Pegawai);
						getch();
						system("cls");
						printAllPegawai(Pegawai);
					}
					else
					{
						Info("Kosong...");
					}
					getch();
					break;

			case 3: if(!isEmptyPegawai(Pegawai))
					{
						printAllPegawai(Pegawai);
						Info("NIP : ");scanf("%d",&nip);
						
						if(isPinjam_Pegawai(Peminjaman,nip)==0)
						{
							gotoxy(49,12);deleteAtPegawai(Pegawai,nip);
							savePegawai(Pegawai);
						}
						else
							Info("Pegawai Masih Meminjam!");
						getch();
						system("cls");
						printAllPegawai(Pegawai);
					}
					else
						Info("Kosong...");
					getch();
					break;

			case 4: a=5,z=5;
					
					gotoxy(3,3);printf("Plat ");gotoxy(16,3);printf("Merk");
				
					gotoxy(3,a);fflush(stdin);gets(datamobil.plat);

					if(isUnikMobil(Mobil,datamobil.plat)==1) 
					{
						gotoxy(17,a);fflush(stdin);gets(datamobil.merk);
						strcpy(datamobil.status,"Ada");
						insertMobil(Mobil,datamobil);
						saveMobil(Mobil);
					}
					else
					{
						Info("Sudah Ada... ");
					}	
					getch();
					break;

				
			case 5:	if(isEmptyMobil (Mobil))
					{
						Info("Kosong...");
					}
					else
					{
						printAllMobil(Mobil);
						Info("Plat: ");fflush(stdin);gets(plat);
						gotoxy(49,12);editMobil(Mobil,plat);
						saveMobil(Mobil);
						getch();
						system("cls");
						printAllMobil(Mobil);
					}
					getch();
					break;
				
				
			case 6: if(!isEmptyMobil (Mobil))
					{
						printAllMobil(Mobil);
						Info("Plat : ");fflush(stdin);gets(plat);
						
						if(isPinjam_Mobil(Peminjaman,plat)==0)
						{
							gotoxy(49,12);deleteAtMobil(Mobil,plat);
							saveMobil(Mobil);
						}
						else
							Info("Mobil Masih Dipinjam!");
						getch();
						system("cls");
						printAllMobil(Mobil);
					}
					else
						Info("Kosong...");
					getch();
					break;
					
				
			case 7: a=5;z=5;
					
					gotoxy(3,3);printf("Nip ");gotoxy(16,3);printf("Plat");
					
					gotoxy(3,a);scanf("%d",&nip);
					
					gotoxy(17,a);fflush(stdin);gets(plat);
					insertPeminjaman_input (Peminjaman,Pegawai,Mobil,plat,nip);
					savePegawai(Pegawai);
					saveMobil(Mobil);
					savePeminjaman(Peminjaman);
					
					getch();
					break;

			case 8: if(!isEmptyPeminjaman(Peminjaman))
					{
						Info("Plat: ");fflush(stdin);gets(plat);
						deleteAtPeminjaman(Peminjaman,Pegawai,Mobil,plat);
						savePegawai(Pegawai);
						saveMobil(Mobil);
						savePeminjaman(Peminjaman);
					}
					else
						Info("Kosong!");
					getch();
					break;

			case 9: sortMobil (Mobil);
					printAllMobil(Mobil);
					getch();
					break;

			case 10:sortPegawai_byNip (Pegawai);
					printAllPegawai (Pegawai);
					getch();
					break;

			case 11:sortPeminjaman_byNip (Peminjaman);
					printAllPeminjaman(Peminjaman);
					getch();
					break;

			case 12:Info("NIP: "); scanf("%d",&nip);
					
					printAllPeminjaman_SatuPegawai(Peminjaman,nip);
					
					getch();
					break;

			case 13:printAllPegawai_byJumlahPeminjaman(Pegawai);
					getch();
					break;

			case 0 :getch();
					break;
		}

	

	}while(Y!=17);

}