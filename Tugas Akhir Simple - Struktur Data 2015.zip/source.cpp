#include "header.h"


//==================================================//
//////////////////////////////////////////////////////
////////////////////GOTOXY////////////////////////////
//////////////////////////////////////////////////////
//==================================================//

void gotoxy(int x,int y)
{
	HANDLE hConsoleOutput;
	COORD dwCursorPosition;
	dwCursorPosition.X=x;
	dwCursorPosition.Y=y;
	hConsoleOutput=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hConsoleOutput,dwCursorPosition);
}

void setcolor(unsigned short color)
{
	HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hCon,color);
}

void SetColor(char text, char background)
{
	unsigned short color=background*16+text;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),color);
}

void setLayar(int lebar,int tinggi)						  
{
	SMALL_RECT windowSize = {0,0,lebar,tinggi};					  
   	COORD bufferSize = {lebar+1,tinggi+1};						  
	SetConsoleScreenBufferSize(GetStdHandle(STD_OUTPUT_HANDLE), bufferSize);
    SetConsoleWindowInfo(GetStdHandle(STD_OUTPUT_HANDLE), 1, &windowSize);	
}

//==================================================//
//////////////////////////////////////////////////////
////////////////////HIDE CURSOR///////////////////////
//////////////////////////////////////////////////////
//==================================================//

void HideCursor()
{
	CONSOLE_CURSOR_INFO ConCurInf;										
	ConCurInf.dwSize=20;												
	ConCurInf.bVisible=FALSE;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE),&ConCurInf);
}


//==================================================//
//////////////////////////////////////////////////////
////////////////////CREATE EMPTY/////////////////////
/////////////////////////////////////////////////////
//==================================================//

void createEmptyMobil(ListMobil &Mobil)
{
     Mobil.First= NULL;
}

void createEmptyPegawai(ListPegawai &Pegawai)
{
     Pegawai.First= NULL;
}

void createEmptyPeminjaman(ListPeminjaman &Pinjam)
{
     Pinjam.First= NULL;
}

//==================================================//
//////////////////////////////////////////////////////
////////////////////FILE LOAD/////////////////////////
//////////////////////////////////////////////////////
//==================================================//

void loadMobil (ListMobil &Mobil)  //isi data dari txt ke linkedlist
{
	FILE *p; //pointer utama utk loaddata
	FILE *f; //pointer bantu utk cari tahu txt ada isinya/tidak
	mobil datamobil;

	//Code ini untuk mengetahui di dalam txt ada isinya atau enggak
	f=fopen("mobil.txt","r");	//buka data_mobil.txt
	fseek(f, 0, SEEK_END);			//melihat isi dalam txt sampai akhir
	unsigned long textSize = (unsigned long)ftell(f); //ukuran teks di lihat dari isi txt
	fclose(f);						//setelah buka txt, harus di tutup txt nya
	//End
	
	//Code ini untuk meload data dari txt ke linked list nya
	p=fopen("mobil.txt","r");
	
	if(textSize==0)
		printf("kosong!");
	else
	{
		while( !feof(p) ){ //feof artinya end of file dari txt, jika belum sampai akhiPinjam, perulangan berlanjut!
			fscanf(p,"\n\nplat : %[^\n]s",&datamobil.plat);
			fscanf(p,"\nmerk : %[^\n]s",&datamobil.merk);
			fscanf(p,"\nstatus : %[^\n]s",&datamobil.status);
			insertMobil(Mobil,datamobil);
		}
	}
	fclose(p); //jgn lupa tutup txt nya
}

void loadPegawai(ListPegawai &Pegawai)
{
	FILE *p;
	FILE *f;
	pegawai datapegawai;

	f=fopen("pegawai.txt","r");
	fseek(f, 0, SEEK_END);
	unsigned long textSize = (unsigned long)ftell(f);
	fclose(f);

	p=fopen("pegawai.txt","r");
	
	if(textSize==0)
		printf("kosong!");
	else
	{
		while( !feof(p) )
		{
			fscanf(p,"\n\nnip : %d",&datapegawai.NIP);
			fscanf(p,"\nnama : %[^\n]s",&datapegawai.nama);
			fscanf(p,"\njumlah : %d",&datapegawai.jumlahPeminjaman);
			insertPegawai(Pegawai,datapegawai);
		}
	}
	fclose(p);
}

void loadPeminjaman(ListPeminjaman &Pinjam)
{
	FILE *p;
	FILE *f;
	pegawai datapegawai;
	mobil datamobil;
	
	f=fopen("peminjaman.txt","r");
	fseek(f, 0, SEEK_END);
	unsigned long textSize = (unsigned long)ftell(f);
	fclose(f);

	p=fopen("peminjaman.txt","r");
	
	if(textSize==0)
		printf("kosong!");
	else
	{
		while( !feof(p) ){
			fscanf(p,"\n\nnip : %d",&datapegawai.NIP);
			fscanf(p,"\nnama : %[^\n]s",&datapegawai.nama);
			fscanf(p,"\nplat : %[^\n]s",&datamobil.plat);
			fscanf(p,"\nmerk : %[^\n]s",&datamobil.merk);
			fscanf(p,"\nstatus : %[^\n]s",&datamobil.status);
			
			insertPeminjaman(Pinjam, datapegawai, datamobil);
		}
	}
	fclose(p);
}


//==================================================//
//////////////////////////////////////////////////////
////////////////////FILE SAVE/////////////////////////
//////////////////////////////////////////////////////
//==================================================//

void saveMobil(ListMobil Mobil) //isi data dari linked list ke txt
{
	FILE *p;
	addressMobil bantu = Mobil.First;

	p=fopen("mobil.txt","w");
	
	if (!isEmptyMobil(Mobil))
	{
		do
		{
			fprintf(p,"\n\nplat : %s",bantu->Mobil.plat);
			fprintf(p,"\nmerk : %s",bantu->Mobil.merk);
			fprintf(p,"\nstatus : %s",bantu->Mobil.status);
			bantu = bantu->next;
		} while (bantu != Mobil.First);
	}
	fclose(p);
}

void savePegawai(ListPegawai Pegawai)
{
	FILE *p;
	addressPegawai bantu = Pegawai.First;

	p=fopen("pegawai.txt","w");
	
	if (!isEmptyPegawai(Pegawai))
	{
		do
		{
			fprintf(p,"\n\nnip : %d",bantu->Pegawai.NIP);
			fprintf(p,"\nnama : %s",bantu->Pegawai.nama);
			fprintf(p,"\njumlah : %d",bantu->Pegawai.jumlahPeminjaman);
			bantu = bantu->next;
		} while (bantu != Pegawai.First);
	}
	fclose(p);
}

void savePeminjaman(ListPeminjaman Pinjam)
{
	FILE *p;
	addressPeminjaman bantu = Pinjam.First;

	p=fopen("peminjaman.txt","w");
	
	if (!isEmptyPeminjaman(Pinjam))
	{
		do
		{
			fprintf(p,"\n\nnip : %d",bantu->Pegawai.NIP);
			fprintf(p,"\nnama : %s",bantu->Pegawai.nama);
			fprintf(p,"\nplat : %s",bantu->Mobil.plat);
			fprintf(p,"\nmerk : %s",bantu->Mobil.merk);
			fprintf(p,"\nstatus : %s",bantu->Mobil.status);
			
			bantu = bantu->next;
		} while (bantu != Pinjam.First);
	}
	fclose(p);
}


//==================================================//
//////////////////////////////////////////////////////
////////////////////IS EMPTY//////////////////////////
/////////////////////////////////////////////////////
//==================================================//

int isEmptyMobil (ListMobil Mobil)
{
    if (Mobil.First == NULL)
       return 1;
    else
       return 0;
}

int isEmptyPegawai (ListPegawai Pegawai)
{
    if (Pegawai.First == NULL)
       return 1;
    else
       return 0;
}

int isEmptyPeminjaman (ListPeminjaman Pinjam)
{
    if (Pinjam.First == NULL)
       return 1;
    else
       return 0;
}

//==================================================//
//////////////////////////////////////////////////////
/////////////////////ALOKASI//////////////////////////
//////////////////////////////////////////////////////
//==================================================//

addressMobil alokasiMobil (mobil m)
{
	addressMobil M = new (NodeMobil);
	M->Mobil=m; 
	M->next=NULL;
	return M;
}

addressPegawai alokasiPegawai (pegawai p)
{
	addressPegawai P = new (NodePegawai);
	P->Pegawai=p; 
	P->next=NULL;
	return P;
}

addressPeminjaman alokasiPeminjaman (pegawai p, mobil m)
{
	addressPeminjaman PP = new (NodePeminjaman);
	PP->Pegawai=p; 
	PP->Mobil=m;
	PP->next=NULL;
	return PP;
}

//==================================================//
//////////////////////////////////////////////////////
/////////////////////INSERT///////////////////////////
//////////////////////////////////////////////////////
//==================================================//

void insertPegawai(ListPegawai &Pegawai, pegawai databaru)
{
 	addressPegawai p = alokasiPegawai (databaru); 	
	addressPegawai last;
	
	if(isEmptyPegawai(Pegawai))
 	{
  		Pegawai.First = p;  
		Pegawai.First->next = Pegawai.First;
 	}
 	else
 	{
  		last=findLastPegawai(Pegawai);
		last->next = p;
		p->next = Pegawai.First;
 	}

	Info("Berhasil Masuk...");
}

void insertMobil(ListMobil &Mobil, mobil databaru)
{
 	addressMobil m = alokasiMobil(databaru);	
	addressMobil last;

 	if(isEmptyMobil(Mobil))
 	{
  		Mobil.First = m;  
		Mobil.First->next = Mobil.First;
 	}
 	else
 	{
  		last=findLastMobil(Mobil);
		last->next = m;
		m->next = Mobil.First;
 	}
	Info("Berhasil Masuk...");
}

void insertPeminjaman(ListPeminjaman &Pinjam, pegawai datapegawai, mobil datamobil)
{
 	addressPeminjaman last;
	addressPeminjaman pp = alokasiPeminjaman(datapegawai,datamobil);

 	if(isEmptyPeminjaman(Pinjam))
 	{
  		Pinjam.First = pp;  
		Pinjam.First->next = Pinjam.First;
 	}
 	else
 	{
  		last=findLastPeminjaman(Pinjam);
		last->next = pp;
		pp->next = Pinjam.First;
 	}
	Info("Berhasil Masuk...");
}

void insertPeminjaman_input (ListPeminjaman &Pinjam, ListPegawai &Pegawai, ListMobil &Mobil, string plat, int nip)
{
	addressMobil foundMobil = searchMobil (Mobil, plat);
	addressPegawai foundPegawai = searchPegawai (Pegawai, nip);

	if(isEmptyPegawai(Pegawai) && isEmptyMobil(Mobil))
	{
		Info("Kosong...");
	}
	else
 	{
		if(foundMobil==NULL || foundPegawai==NULL)
			Info("Tidak Ditemukan...");
		else if(foundMobil!=NULL && foundPegawai!=NULL && strcmpi(foundMobil->Mobil.status,"Ada")==0)
		{
			insertPeminjaman(Pinjam, foundPegawai->Pegawai, foundMobil->Mobil);
			strcpy(foundMobil->Mobil.status,"Dipakai");
			foundPegawai->Pegawai.jumlahPeminjaman++;
		}
		else
			Info("Sedang Dipakai...");
 	}
}


//==================================================//
//////////////////////////////////////////////////////
//////////////////// SORTING /////////////////////////
//////////////////////////////////////////////////////
//==================================================//

void swapMobil(mobil &a, mobil &b)
{
	mobil temp;
	temp=a;
	a=b;
	b=temp;
}

void swapPegawai(pegawai &a, pegawai &b)
{
	pegawai temp;
	temp=a;
	a=b;
	b=temp;
}

void sortMobil (ListMobil &Mobil)
{
	addressMobil i, j;
	
	if(!isEmptyMobil(Mobil))
	{
		for(i= Mobil.First;i->next!=Mobil.First;i=i->next)
		{
			for(j=i->next;j!=Mobil.First;j=j->next)
			{
				if(strcmpi(i->Mobil.plat, j->Mobil.plat)>=0)
				{
					swapMobil(i->Mobil,j->Mobil);
				}
			}
		}
	}
}

void sortPegawai_byNip (ListPegawai &Pegawai)
{
	addressPegawai i, j;

	if(!isEmptyPegawai(Pegawai))
	{
		for(i = Pegawai.First;i->next!=Pegawai.First;i=i->next)
		{
			for(j=i->next;j!=Pegawai.First;j=j->next)
			{
				if(i->Pegawai.NIP > j->Pegawai.NIP)
				{
					swapPegawai(i->Pegawai,j->Pegawai);
				}
			}
		}
	}
}

void sortPegawai_byJumlahRent (ListPegawai &Pegawai)
{
	addressPegawai i, j;

	if(!isEmptyPegawai(Pegawai))
	{
		for(i = Pegawai.First;i->next!=Pegawai.First;i=i->next)
		{
			for(j=i->next;j!=Pegawai.First;j=j->next)
			{
				if(i->Pegawai.jumlahPeminjaman < j->Pegawai.jumlahPeminjaman)
				{
					swapPegawai(i->Pegawai,j->Pegawai);
				}
			}
		}
	}
}

void sortPeminjaman_byNip (ListPeminjaman &Pinjam)
{
	addressPeminjaman i, j;

	if(!isEmptyPeminjaman(Pinjam))
	{
		for(i = Pinjam.First;i->next!=Pinjam.First;i=i->next)
		{
			for(j=i->next;j!=Pinjam.First;j=j->next)
			{
				if(i->Pegawai.NIP > j->Pegawai.NIP)
				{
					swapMobil(i->Mobil,j->Mobil);
					swapPegawai(i->Pegawai,j->Pegawai);
				}
			}
		}
	}
}

void sortPeminjaman_byPlat (ListPeminjaman &Pinjam)
{
	addressPeminjaman i, j;

	if(!isEmptyPeminjaman(Pinjam))
	{
		for(i = Pinjam.First;i->next!=Pinjam.First;i=i->next)
		{
			for(j=i->next;j!=Pinjam.First;j=j->next)
			{
				if(strcmpi(i->Mobil.plat,j->Mobil.plat)>=0)
				{
					swapMobil(i->Mobil,j->Mobil);
					swapPegawai(i->Pegawai,j->Pegawai);
				}
			}
		}
	}
}


//==================================================//
//////////////////////////////////////////////////////
/////////////////////FINDLAST/////////////////////////
//////////////////////////////////////////////////////
//==================================================//

addressMobil findLastMobil (ListMobil Mobil)
{
	addressMobil last = Mobil.First;
	if(isEmptyMobil(Mobil)) 
		return NULL;
	else
	{
		while (last->next!=Mobil.First)
		{
			last=last->next;
		}
		return last;
	}
}

addressPegawai findLastPegawai (ListPegawai Pegawai)
{
	addressPegawai last = Pegawai.First;
	if(isEmptyPegawai(Pegawai)) 
		return NULL;
	else
	{
		while (last->next!=Pegawai.First)
		{
			last=last->next;
		}
		return last;
	}
}

addressPeminjaman findLastPeminjaman (ListPeminjaman Pinjam)
{
	addressPeminjaman last = Pinjam.First;
	if(isEmptyPeminjaman(Pinjam)) 
		return NULL;
	else
	{
		while (last->next!=Pinjam.First)
		{
			last=last->next;
		}
		return last;
	}
}

//==================================================//
//////////////////////////////////////////////////////
////////////////////SEARCH AT/////////////////////////
//////////////////////////////////////////////////////
//==================================================//

addressMobil searchMobil (ListMobil Mobil, string plat)
{
	if (isEmptyMobil(Mobil))
		return NULL;
	else
	{
		addressMobil bantu=Mobil.First;
		do
		{
			if(strcmpi(bantu->Mobil.plat,plat)==0)
			{
				return bantu;
				break;
			}
			else
				bantu=bantu->next;
		}while (bantu!= Mobil.First);
	}

	return NULL;
}

addressPegawai searchPegawai (ListPegawai Pegawai, int nip)
{
	if (isEmptyPegawai(Pegawai))
		return NULL;
	else
	{
		addressPegawai bantu=Pegawai.First;
		do
		{
			if(bantu->Pegawai.NIP==nip)
			{
				return bantu;
				break;
			}
			else
				bantu=bantu->next;
		}while (bantu!= Pegawai.First);
	}	
	return NULL;
}

addressPeminjaman searchPeminjamanbyPlat (ListPeminjaman Pinjam, string plat)
{
	if (isEmptyPeminjaman(Pinjam))
		return NULL;
	else
	{
		addressPeminjaman bantu=Pinjam.First;
		do
		{
			if(strcmpi(bantu->Mobil.plat,plat)==0)
			{
				return bantu;
				break;
			}
			else
				bantu=bantu->next;
		}while (bantu!= Pinjam.First);
	}
	return NULL;
}

addressPeminjaman searchPeminjamanbyNIP (ListPeminjaman Pinjam, int nip)
{
	if (isEmptyPeminjaman(Pinjam))
		return NULL;
	else
	{
		addressPeminjaman bantu=Pinjam.First;
		do
		{
			if(bantu->Pegawai.NIP==nip)
			{
				return bantu;
				break;
			}
			else
				bantu=bantu->next;
		}while (bantu!= Pinjam.First);
	}
	return NULL;
}

//==================================================//
//////////////////////////////////////////////////////
////////////////////IS UNIQUE/////////////////////////
//////////////////////////////////////////////////////
//==================================================//

int isUnikPegawai(ListPegawai Pegawai, int nip)
{
	addressPegawai foundPegawai = searchPegawai(Pegawai,nip);
	if(foundPegawai==NULL)
		return 1;
	else if(foundPegawai->Pegawai.NIP==nip)
		return 0;
	else
		return 1;
}

int isUnikMobil(ListMobil Mobil, string plat)
{
	addressMobil foundMobil = searchMobil(Mobil,plat);
	if(foundMobil==NULL)
		return 1;
	else if(strcmpi(foundMobil->Mobil.plat,plat)==0)
		return 0;
	else
		return 1;
}

int isPinjam_Pegawai(ListPeminjaman Pinjam, int nip)
{
	addressPeminjaman foundPeminjaman = searchPeminjamanbyNIP(Pinjam,nip);
	if(foundPeminjaman==NULL)
		return 0;
	else if(foundPeminjaman->Pegawai.NIP==nip)
		return 1;
	else
		return 0;
}

int isPinjam_Mobil(ListPeminjaman Pinjam, string plat)
{
	addressPeminjaman foundPeminjaman = searchPeminjamanbyPlat(Pinjam,plat);
	if(foundPeminjaman==NULL)
		return 0;
	else if(strcmpi(foundPeminjaman->Mobil.plat,plat)==0)
		return 1;
	else
		return 0;
}

//==================================================//
//////////////////////////////////////////////////////
////////////////////PRINT ALL/////////////////////////
//////////////////////////////////////////////////////
//==================================================//

void printAllMobil(ListMobil Mobil)
{
	addressMobil bantu = Mobil.First;
	int y=5,nomor=1,a,z;
	if (isEmptyMobil(Mobil) )
	{
		Info("Data Mobil Kosong ");
	}
	else
	{
		a=5,z=5;
		
		gotoxy(12,3);printf("No");gotoxy(22,3);printf("Plat");gotoxy(34,3);printf("Merk");gotoxy(48,3);printf("Status");
		
		do
		{
			gotoxy(12,y);printf("%d",nomor);
			gotoxy(22,y);printf("%s",bantu->Mobil.plat); 
			gotoxy(34,y);printf("%s",bantu->Mobil.merk); 
			gotoxy(48,y);printf("%s",bantu->Mobil.status);
			bantu = bantu->next;
			y++;nomor++;
		} while (bantu != Mobil.First);
	}
}

void printAllPegawai(ListPegawai Pegawai)
{
	addressPegawai bantu = Pegawai.First;
	int y=5,nomor=1,a,z;
	if (isEmptyPegawai(Pegawai))
	{
		Info("Data pegawai Kosong ");
	}
	else
	{
		a=5,z=5;
		
		gotoxy(10,3);printf("No");gotoxy(22,3);printf("NIP");gotoxy(37,3);printf("Nama");
		
		do
		{
			gotoxy(10,y);printf("%d",nomor);
			gotoxy(22,y);printf("%d",bantu->Pegawai.NIP);
			gotoxy(37,y);printf("%s",bantu->Pegawai.nama);
			bantu = bantu->next;
			y++;nomor++;
		} while (bantu != Pegawai.First);
	}
}


//==================================================//
//////////////////////////////////////////////////////
///////////////////// EDIT ///////////////////////////
//////////////////////////////////////////////////////
//==================================================//

void editMobil (ListMobil &Mobil, string plat)
{
	addressMobil foundMobil=searchMobil(Mobil,plat);
	string merk;
	
 	if(isEmptyMobil(Mobil))
	{
		Info("Kosong...");
	}
	else
 	{
		if(foundMobil!=NULL)
		{
			Info("Merk Mobil : ");fflush(stdin);gets(merk);
			strcpy(foundMobil->Mobil.plat,plat);
			strcpy(foundMobil->Mobil.merk,merk);
			Info("Berhasil Diedit...");
		}
		else
		{
			Info("Tidak Ditemukan...");
		}
 	}
}

void editPegawai (ListPegawai &Pegawai, int nip)
{
	addressPegawai foundPegawai=searchPegawai(Pegawai,nip);
	string nama;

 	if(isEmptyPegawai(Pegawai))
	{
		Info("Kosong...");
	}
	else
 	{
		if(foundPegawai!=NULL)
		{
			Info("Nama pegawai : ");fflush(stdin);gets(nama);
			foundPegawai->Pegawai.NIP=nip;
			strcpy(foundPegawai->Pegawai.nama,nama);
			Info("Berhasil Diedit...");
		}
		else
		{
			Info("Tidak Ditemukan...");
		}
 	}
}

//==================================================//
//////////////////////////////////////////////////////
////////////////////DELETE FIRST//////////////////////
//////////////////////////////////////////////////////
//==================================================//

void deleteFirstMobil (ListMobil &Mobil)
{
	addressMobil last=findLastMobil(Mobil);
	addressMobil hapus;

 	if(isEmptyMobil(Mobil))
	{
		Info("Kosong...");
	}
 	else
 	{
		if(Mobil.First->next == Mobil.First)
		{
			delete(Mobil.First);
			Mobil.First=NULL;
		}
		else
		{
			hapus = Mobil.First;
			Mobil.First = Mobil.First->next;
			last->next = Mobil.First;
			delete (hapus);
		}
 	}
}

void deleteFirstPegawai (ListPegawai &Pegawai)
{
	addressPegawai last=findLastPegawai(Pegawai);
	addressPegawai hapus;
	
 	if(isEmptyPegawai(Pegawai))
	{
		Info("Kosong...");
	}
 	else
 	{
		if(Pegawai.First->next == Pegawai.First)
		{
			delete(Pegawai.First);
			Pegawai.First=NULL;
		}
		else
		{
			hapus = Pegawai.First;
			Pegawai.First = Pegawai.First->next;
			last->next = Pegawai.First;
			delete (hapus);
		}
 	}
}

void deleteFirstPeminjaman (ListPeminjaman &Pinjam)
{
	addressPeminjaman last=findLastPeminjaman(Pinjam);
	addressPeminjaman hapus;

 	if(isEmptyPeminjaman(Pinjam))
	{
		Info("Kosong...");
	}
 	else
 	{
		if(Pinjam.First->next == Pinjam.First)
		{
			delete(Pinjam.First);
			Pinjam.First=NULL;
		}
		else
		{
			hapus = Pinjam.First;
			Pinjam.First = Pinjam.First->next;
			last->next = Pinjam.First;
			delete (hapus);
		}
 	}
}

//==================================================//
//////////////////////////////////////////////////////
////////////////////DELETE AT/////////////////////////
//////////////////////////////////////////////////////
//==================================================//

void deleteAtMobil (ListMobil &Mobil, string plat)
{
	addressMobil foundMobil=searchMobil(Mobil,plat);
	addressMobil prev=Mobil.First;

 	if(isEmptyMobil(Mobil))
	{
		Info("Kosong...");
	}
	else
 	{
		if (foundMobil==NULL)
		{
			Info("Tidak Ditemukan...");
		}
		else if(foundMobil==Mobil.First)
		{
			deleteFirstMobil(Mobil);
			Info("Berhasil Dihapus...");
		}
		else
  		{

   			while(prev->next != foundMobil)
   			{
				prev = prev->next;
   			}
			prev->next=foundMobil->next;
   			delete(foundMobil);
			Info("Berhasil Dihapus...");
  		}
 	}
}

void deleteAtPegawai (ListPegawai &Pegawai, int nip)
{
	addressPegawai foundPegawai=searchPegawai(Pegawai,nip);
	addressPegawai prev=Pegawai.First;
	
 	if(isEmptyPegawai(Pegawai))
	{
		Info("Kosong...");
	}
	else
 	{
		if (foundPegawai==NULL)
		{
			Info("Tidak Ditemukan...");
		}
		else if(foundPegawai==Pegawai.First)
		{
			deleteFirstPegawai(Pegawai);
			Info("Berhasil Dihapus...");
		}
		else
  		{
   			while(prev->next!=foundPegawai)
   			{
				prev = prev->next;
   			}
			prev->next=foundPegawai->next;
   			delete(foundPegawai);
			Info("Berhasil Dihapus...");
  		}
 	}
}

void deleteAtPeminjaman (ListPeminjaman &Pinjam, ListPegawai &Pegawai, ListMobil &Mobil, string plat)
{
	addressPeminjaman foundPeminjaman= searchPeminjamanbyPlat(Pinjam,plat);
	addressMobil foundMobil = searchMobil(Mobil,plat);
	addressPegawai foundPegawai;
	addressPeminjaman prev=Pinjam.First;

 	if(isEmptyPeminjaman(Pinjam))
	{
		Info("Kosong...");
	}
	else
 	{
		if(foundMobil==NULL)
		{
			Info("Tidak Ditemukan...");
		}
		else if (foundPeminjaman==NULL) //bila pencarian data peminjaman tidak ketemu/tidak ada
		{
			Info("Tidak Ditemukan...");
		}
		else if(foundPeminjaman==Pinjam.First){ //bila di list ada 1 data saja
			//cari pegawai agar dpt dikurangi jumlahPeminjamannya nanti
			foundPegawai = searchPegawai (Pegawai, foundPeminjaman->Pegawai.NIP);
			//baru di delete
			deleteFirstPeminjaman(Pinjam);
			//pengembalian mobil berarti jumlah peminjaman si pegawai tsb berkurang
			foundPegawai->Pegawai.jumlahPeminjaman--;
			//dan mengubah status mobilnya menjadi tersedia
			strcpy(foundMobil->Mobil.status,"Ada");
			Info("Pengembalian Berhasil...");
		}
		else //bila di list ada 2 data/lebih
  		{
   			while(prev->next!=foundPeminjaman)
   			{
				prev = prev->next;
   			}
			prev->next=foundPeminjaman->next;
			foundPegawai = searchPegawai (Pegawai, foundPeminjaman->Pegawai.NIP);
   			delete(foundPeminjaman);
			foundPegawai->Pegawai.jumlahPeminjaman--;
			strcpy(foundMobil->Mobil.status,"Ada");
			Info("Pengembalian Berhasil...");
  		}	
 	}
}



void printAllPegawai_byJumlahPeminjaman(ListPegawai Pegawai)
{
	sortPegawai_byJumlahRent (Pegawai);
	addressPegawai bantu = Pegawai.First;
	int y=5,nomor=1,a,z;
	if (isEmptyPegawai(Pegawai))
	{
		Info("Kosong ");
	}
	else
	{
		a=5,z=5;
		
		gotoxy(10,3);printf("Nip");gotoxy(22,3);printf("Nama");gotoxy(37,3);printf("Jml");
		
		do
		{
			gotoxy(10,y);printf("%d",bantu->Pegawai.NIP);
			gotoxy(22,y);printf("%s",bantu->Pegawai.nama);
			gotoxy(37,y);printf("%d",bantu->Pegawai.jumlahPeminjaman);
			bantu = bantu->next;
			y++;nomor++;
		} while (bantu != Pegawai.First);
	}
}

void printAllPeminjaman(ListPeminjaman Pinjam)
{
	addressPeminjaman bantu = Pinjam.First;
	int y=5,nomor=1;
	if (isEmptyPeminjaman(Pinjam))
	{
		Info("Kosong ");
	}
	else
	{
		gotoxy(10,3);printf("No");gotoxy(22,3);printf("Nip");gotoxy(37,3);printf("Nama");gotoxy(52,3);printf("Plat");gotoxy(67,3);printf("Merk");
		do
		{
			gotoxy(10,y);printf("%d",nomor);
			gotoxy(22,y);printf("%d",bantu->Pegawai.NIP);
			gotoxy(37,y);printf("%s",bantu->Pegawai.nama);
			gotoxy(52,y);printf("%s",bantu->Mobil.plat);
			gotoxy(67,y);printf("%s",bantu->Mobil.merk);
			bantu = bantu->next;
			y++;nomor++;
		} while (bantu != Pinjam.First);
	}
}

void printAllPeminjaman_SatuPegawai(ListPeminjaman Pinjam, int nip)
{
	addressPeminjaman bantuPeminjaman = Pinjam.First;
	addressPeminjaman foundPeminjaman = searchPeminjamanbyNIP (Pinjam,nip); //tes dgn search apakah hasil pencarian ada/tidak

	int y=5,nomor=1;
	
	if(isEmptyPeminjaman(Pinjam))
		Info("Kosong...");
	else if(foundPeminjaman==NULL)
		Info("Belum Pernah Pinjam!");
	else
	{
		//Sorting List Rent berdasarkan Plat
		sortPeminjaman_byPlat(Pinjam);
		//Kemudian tampilkan List Rent yang sudah tersorting
		system("CLS");
		gotoxy(10,3);printf("No");gotoxy(22,3);printf("Nip");gotoxy(37,3);printf("Nama");gotoxy(52,3);printf("Plat");gotoxy(67,3);printf("Merk");
		do
		{
			if(bantuPeminjaman->Pegawai.NIP==nip)
			{
				gotoxy(10,y);printf("%d",nomor);
				gotoxy(22,y);printf("%d",bantuPeminjaman->Pegawai.NIP);
				gotoxy(37,y);printf("%s",bantuPeminjaman->Pegawai.nama);
				gotoxy(52,y);printf("%s",bantuPeminjaman->Mobil.plat);
				gotoxy(67,y);printf("%s",bantuPeminjaman->Mobil.merk);
				y++;nomor++;
			}
			bantuPeminjaman = bantuPeminjaman->next;
			
		} while (bantuPeminjaman != Pinjam.First);
	}
}




//==================================================//
//////////////////////////////////////////////////////
/////////////////INFORMATION POP UP///////////////////
//////////////////////////////////////////////////////
//==================================================//

void Info(string kata)
{
	int a,b;

	/*SetColorbackground abu2*/
	gotoxy(3,2);SetColor(hitam,abuabuX);

	/*buat kotak kedua utk tampilan dalam kotak pertama*/
	for(a=22;a<71;a++)
	{
		for(b=11;b<16;b++)
		{
			gotoxy(a,b);printf("  ");
		}
					
	}
	/*print informasi*/
	gotoxy(27,12);printf("%s",kata);
}

