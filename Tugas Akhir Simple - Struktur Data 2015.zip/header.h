#include <stdio.h>  
#include <conio.h> 
#include <string.h>
#include <stdlib.h> 
#include <iostream.h>
#include <windows.h>
#include <ctype.h>
#include <time.h>

typedef char string[99];
typedef struct NodeMobil *addressMobil;
typedef struct NodePegawai *addressPegawai;
typedef struct NodePeminjaman *addressPeminjaman;

typedef struct
{
	int NIP;
	int jumlahPeminjaman;
	string nama;
}pegawai;

typedef struct
{	
	string plat,merk,status;
}mobil;

typedef struct NodeMobil  
{ 
	mobil Mobil;
	addressMobil next; 	
}NodeMobil;

typedef struct NodePegawai  
{ 
	pegawai Pegawai;
	addressPegawai next; 	
}NodePegawai;

typedef struct NodePeminjaman  
{ 
	pegawai Pegawai;
	mobil Mobil;
	addressPeminjaman next; 	
}NodePeminjaman; 

typedef struct  
{ 
	addressMobil First; 
}ListMobil;

typedef struct  
{ 
	addressPegawai First; 
}ListPegawai;

typedef struct  
{ 
	addressPeminjaman First; 
}ListPeminjaman;

const char putih=15, kuning=14, ungu=13, merah=12, sky=11, hijau=20, biru=9, abuabu=8;
const char abuabuX=7, kuningX=6, unguX=5, merahX=4, skyX=3, hijauX=2, biruX=1, hitam=0;

void gotoxy(int x,int y);
void setcolor(unsigned short color);
void HideCursor();
void SetColor(char text, char background);
void setLayar(int lebar,int tinggi);
void Info(string kata);
void loadMobil(ListMobil &Mobil);
void saveMobil(ListMobil Mobil);
void loadPegawai(ListPegawai &Pegawai);
void savePegawai(ListPegawai Pegawai);
void loadPeminjaman(ListPeminjaman &Pinjam);
void savePeminjaman(ListPeminjaman Pinjam);

void createEmptyMobil (ListMobil &Mobil);
void createEmptyPegawai (ListPegawai &Pegawai);
void createEmptyPeminjaman (ListPeminjaman &Pinjam);
int isEmptyMobil (ListMobil Mobil);
int isEmptyPegawai (ListPegawai Pegawai);
int isEmptyPeminjaman (ListPeminjaman Pinjam);
addressMobil alokasiMobil (mobil m);
addressPegawai alokasiPegawai (pegawai p);
addressPeminjaman alokasiPeminjaman (pegawai p, mobil m);
addressMobil findLastMobil (ListMobil Mobil);
addressPegawai findLastPegawai (ListPegawai Pegawai);
addressPeminjaman findLastPeminjaman (ListPeminjaman Pinjam);
addressMobil searchMobil (ListMobil Mobil, string plat);
addressPegawai searchPegawai (ListPegawai Pegawai, int nip);
addressPeminjaman searchPeminjamanbyPlat (ListPeminjaman Pinjam, string plat);
addressPeminjaman searchPeminjamanbyNIP (ListPeminjaman Pinjam, int nip);


int isUnikPegawai (ListPegawai Pegawai, int nip);
int isUnikMobil (ListMobil Mobil, string plat);
int isPinjam_Pegawai(ListPeminjaman Pinjam, int nip);
int isPinjam_Mobil(ListPeminjaman Pinjam, string plat);
void swapMobil(mobil &a, mobil &b);
void swapPegawai(pegawai &a, pegawai &b);
void sortMobil (ListMobil &Mobil);
void sortPegawai_byNip (ListPegawai &Pegawai);
void sortPegawai_byJumlahRent (ListPegawai &Pegawai);
void sortPeminjaman_byNip (ListPeminjaman &Pinjam);
void sortPeminjaman_byPlat (ListPeminjaman &Pinjam);

void insertPegawai (ListPegawai &Pegawai, pegawai p);
void insertMobil (ListMobil &Mobil, mobil m);
void insertPeminjaman(ListPeminjaman &Pinjam, pegawai p, mobil m);
void insertPeminjaman_input (ListPeminjaman &Pinjam, ListPegawai &Pegawai, ListMobil &Mobil, string plat, int nip);
void printAllMobil (ListMobil Mobil);
void printAllPegawai (ListPegawai Pegawai);
void printAllPeminjaman (ListPeminjaman Pinjam);
void printAllPeminjaman_SatuPegawai(ListPeminjaman Pinjam, int nip);
void printAllPegawai_byJumlahPeminjaman(ListPegawai Pegawai);
void editMobil (ListMobil &Mobil, string plat);
void editPegawai (ListPegawai &Pegawai, int nip);
void deleteFirstMobil (ListMobil &Mobil);
void deleteFirstPegawai (ListPegawai &Pegawai);
void deleteFirstPeminjaman (ListPeminjaman &Pinjam);
void deleteAtMobil (ListMobil &Mobil,string plat);
void deleteAtPegawai (ListPegawai &Pegawai, int nip);
void deleteAtPeminjaman (ListPeminjaman &Pinjam, ListPegawai &Pegawai, ListMobil &Mobil, string plat);




