/*
 * Main.java
 *
 * Created on November 27, 2013, 10:40 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package singleton;
import java.util.*;

/**
 *
 * @author Sony Vaio
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
                AdministratorInstantiator S1 = new AdministratorInstantiator("Aan","4567");
		AdministratorInstantiator S2 = new AdministratorInstantiator("Edy","1233");
                AdministratorInstantiator S3 = new AdministratorInstantiator("Karen","5555");
    }
    
}

class Administrator
{
	private static Administrator instance = null;
	String Nama,NIP;
	protected Administrator(String Nama, String NIP)
	{
		this.Nama=Nama;
		this.NIP=NIP;
	}

	public static Administrator getInstance(String Nama,String NIP)
	{
		if(instance == null)
		{
			instance = new Administrator(Nama,NIP);
			System.out.println("Objek Administrator " + Nama + " dengan NIP " + NIP + " Terbentuk");
		}
		else
			System.out.println("Objek Administrator " + Nama + " dengan NIP " + NIP + " tidak  terbentuk");

		return instance;
	}
}


class AdministratorInstantiator
{
	public AdministratorInstantiator(String Nama, String NIP)
	{
		Administrator instance = Administrator.getInstance(Nama, NIP);

	}
}
